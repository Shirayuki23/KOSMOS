<?php
session_start();
include 'koneksi.php';

// Cek apakah parameter 'id' ada di URL dan berupa bilangan bulat
if (!isset($_GET['id']) || $_GET['id'] === '' || !ctype_digit((string) $_GET['id'])) {
    header("Location: katalog-kamar.php");
    exit;
}

$id_kamar = (int) $_GET['id'];

// Ambil data kamar berdasarkan ID (prepared statement)
$stmt = $conn->prepare('SELECT * FROM kamar WHERE id = ?');
$stmt->bind_param('i', $id_kamar);
$stmt->execute();
$query = $stmt->get_result();
$kamar = $query->fetch_assoc();

// Jika kamar tidak ditemukan di database
if (!$kamar) {
    header("Location: katalog-kamar.php");
    exit;
}

// Slider foto: foto utama kamar (kolom 'foto') + foto pendukung milik kos.
$foto_utama = (!empty($kamar['foto']) && file_exists("uploads/kamar/" . $kamar['foto']))
    ? "uploads/kamar/" . $kamar['foto'] : "assets/img/kamar1.jpeg";
$pendukung  = ["assets/img/kamar2.jpeg", "assets/img/wc.jpeg"];
$slider_foto = array_values(array_unique(array_merge([$foto_utama], $pendukung)));
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Detail Kamar No. <?= htmlspecialchars($kamar['nomor_kamar']); ?> - Kosmos</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #111111;
            margin: 0;
            padding: 0;
        }

        /* Navbar Header */
        .navbar {
            background: #111111;
            color: #ffffff;
            padding: 18px 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar h1 { margin: 0; font-size: 22px; letter-spacing: 2px; }
        .nav-links a { color: #ffffff; text-decoration: none; margin-left: 20px; font-size: 14px; font-weight: 500; }
        .nav-links a.btn-login { background: #ffffff; color: #111111; padding: 8px 18px; border-radius: 4px; font-weight: bold; }
        .nav-links a.btn-login:hover { background: #cccccc; }

        /* Container Detail */
        .container {
            max-width: 900px;
            margin: 40px auto;
            padding: 0 20px;
        }
        .back-link {
            display: inline-block;
            color: #111;
            text-decoration: none;
            font-weight: bold;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .back-link:hover { text-decoration: underline; }

        .detail-card {
            background: #ffffff;
            border: 2px solid #111111;
            border-radius: 6px;
            box-shadow: 6px 6px 0px #111111;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        /* CSS Slider / Carousel Foto */
        .slider-container {
            position: relative;
            width: 100%;
            height: 400px;
            background: #000;
            overflow: hidden;
        }
        .slide {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            transition: opacity 0.5s ease-in-out;
        }
        .slide.active {
            opacity: 1;
        }
        .slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        /* Tombol Navigasi Slider */
        .slider-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(0, 0, 0, 0.7);
            color: #fff;
            border: none;
            padding: 12px 16px;
            cursor: pointer;
            font-size: 18px;
            font-weight: bold;
            border-radius: 3px;
            transition: background 0.2s;
        }
        .slider-btn:hover { background: rgba(255, 255, 255, 0.9); color: #000; }
        .prev { left: 15px; }
        .next { right: 15px; }

        /* Indikator Titik Slider */
        .slider-dots {
            position: absolute;
            bottom: 15px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 8px;
        }
        .dot {
            width: 10px;
            height: 10px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 50%;
            cursor: pointer;
            transition: background 0.2s;
        }
        .dot.active {
            background: #ffffff;
        }

        /* Detail Konten */
        .content-body {
            padding: 35px;
        }
        .header-info {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-bottom: 2px solid #eee;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }
        .header-info h2 {
            margin: 0 0 10px 0;
            font-size: 28px;
        }
        .badge-status {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }
        .harga-box {
            font-size: 24px;
            font-weight: bold;
            color: #111;
            margin-bottom: 25px;
        }
        .section-block {
            margin-bottom: 25px;
        }
        .section-block h4 {
            margin: 0 0 8px 0;
            font-size: 16px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #333;
        }
        .section-block p {
            margin: 0;
            color: #555;
            line-height: 1.6;
            font-size: 15px;
        }
        .btn-pesan {
            display: block;
            text-align: center;
            background: #111111;
            color: #ffffff;
            text-decoration: none;
            padding: 14px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 15px;
            transition: background 0.2s;
            margin-top: 30px;
        }
        .btn-pesan:hover { background: #333333; }
        .btn-disabled {
            display: block;
            text-align: center;
            background: #cccccc;
            color: #666666;
            padding: 14px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 15px;
            cursor: not-allowed;
            margin-top: 30px;
        }

        /* Footer */
        .footer {
            background: #111111;
            color: #888888;
            text-align: center;
            padding: 20px;
            font-size: 13px;
            margin-top: 60px;
        }
    </style>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <!-- Navbar Header -->
    <div class="navbar">
        <h1>KOSMOS</h1>
        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="katalog-kamar.php">Katalog Kamar</a>
            <?php if (isset($_SESSION['login'])) { ?>
                <?php if ($_SESSION['role'] == 'admin') { ?>
                    <a href="admin/dashboard.php" class="btn-login">Dashboard Admin</a>
                    <a href="logout.php">Logout</a>
                <?php } else { ?>
                    <a href="user/dashboard.php" class="btn-login">Dashboard Saya</a>
                    <a href="logout.php">Logout</a>
                <?php } ?>
            <?php } else { ?>
                <a href="register.php">Daftar</a>
                <a href="login.php" class="btn-login">Login</a>
            <?php } ?>
        </div>
    </div>

    <!-- Konten Utama Detail Kamar -->
    <div class="container">
        <a href="katalog-kamar.php" class="back-link">&larr; Kembali ke Katalog</a>

        <div class="detail-card">
            <!-- Slider Foto Kamar -->
            <div class="slider-container">
                <?php foreach ($slider_foto as $index => $foto) { ?>
                    <div class="slide <?= ($index === 0) ? 'active' : ''; ?>">
                        <img src="<?= htmlspecialchars($foto); ?>" alt="Foto Kamar Kosmos">
                    </div>
                <?php } ?>

                <!-- Tombol Navigasi Next/Prev -->
                <button class="slider-btn prev" onclick="changeSlide(-1)">&#10094;</button>
                <button class="slider-btn next" onclick="changeSlide(1)">&#10095;</button>

                <!-- Indikator Dots -->
                <div class="slider-dots">
                    <?php foreach ($slider_foto as $index => $foto) { ?>
                        <span class="dot <?= ($index === 0) ? 'active' : ''; ?>" onclick="currentSlide(<?= $index; ?>)"></span>
                    <?php } ?>
                </div>
            </div>

            <!-- Informasi Detail -->
            <div class="content-body">
                <div class="header-info">
                    <div>
                        <h2>Kamar No. <?= htmlspecialchars($kamar['nomor_kamar']); ?></h2>
                        <p style="margin: 0; color: #666; font-size: 15px;"><strong>Tipe Kamar:</strong> <?= htmlspecialchars($kamar['tipe_kamar']); ?></p>
                    </div>
                    <div>
                        <?php if ($kamar['status'] == 'tersedia') { ?>
                            <span class="badge-status" style="background: #111; color: #fff;">Tersedia</span>
                        <?php } elseif ($kamar['status'] == 'terisi') { ?>
                            <span class="badge-status" style="background: #ddd; color: #333;">Terisi</span>
                        <?php } else { ?>
                            <span class="badge-status" style="background: #666; color: #fff;">Maintenance</span>
                        <?php } ?>
                    </div>
                </div>

                <div class="harga-box">
                    Rp <?= number_format($kamar['harga'], 0, ',', '.'); ?> <span style="font-size: 14px; font-weight: normal; color: #666;">/ bulan</span>
                </div>

                <div class="section-block">
                    <h4>Fasilitas Lengkap</h4>
                    <p><?= nl2br(htmlspecialchars($kamar['fasilitas'])); ?></p>
                </div>

                <div class="section-block">
                    <h4>Ketentuan / Deskripsi Hunian</h4>
                    <p>Kamar eksklusif dengan pencahayaan yang baik, sirkulasi udara lancar, serta keamanan lingkungan kos yang terjaga 24 jam. Cocok untuk mahasiswa maupun karyawan.</p>
                </div>

                <!-- Tombol Aksi -->
                <?php if ($kamar['status'] == 'tersedia') { ?>
                    <a href="register.php" class="btn-pesan">PILIH & DAFTAR KOS SEKARANG</a>
                <?php } else { ?>
                    <div class="btn-disabled">KAMAR SEDANG TIDAK TERSEDIA</div>
                <?php } ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        &copy; <?= date('Y'); ?> Kosmos - Kost Management System. All rights reserved.
    </div>

    <!-- Skrip JavaScript untuk Slider Foto -->
    <script>
        let slideIndex = 0;
        const slides = document.querySelectorAll('.slide');
        const dots = document.querySelectorAll('.dot');

        function showSlide(n) {
            if (n >= slides.length) { slideIndex = 0; }
            if (n < 0) { slideIndex = slides.length - 1; }

            slides.forEach(slide => slide.classList.remove('active'));
            dots.forEach(dot => dot.classList.remove('active'));

            slides[slideIndex].classList.add('active');
            dots[slideIndex].classList.add('active');
        }

        function changeSlide(n) {
            slideIndex += n;
            showSlide(slideIndex);
        }

        function currentSlide(n) {
            slideIndex = n;
            showSlide(slideIndex);
        }

        // Auto slide setiap 4 detik (opsional, bisa dihapus jika tidak ingin otomatis)
        setInterval(() => {
            slideIndex++;
            showSlide(slideIndex);
        }, 4000);
    </script>

</body>
</html>