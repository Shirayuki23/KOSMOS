-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: db_kosmos
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `inventaris`
--

DROP TABLE IF EXISTS `inventaris`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventaris` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_barang` varchar(100) NOT NULL,
  `lokasi` enum('kamar','area_bersama') NOT NULL DEFAULT 'kamar',
  `kamar_id` int(11) DEFAULT NULL,
  `kondisi` enum('baik','perlu_perbaikan','rusak') NOT NULL DEFAULT 'baik',
  `jumlah` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `kamar_id` (`kamar_id`),
  CONSTRAINT `fk_inventaris_kamar` FOREIGN KEY (`kamar_id`) REFERENCES `kamar` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventaris`
--

LOCK TABLES `inventaris` WRITE;
/*!40000 ALTER TABLE `inventaris` DISABLE KEYS */;
INSERT INTO `inventaris` VALUES (1,'Kasur','kamar',2,'baik',1),(2,'Lemari Pakaian','kamar',2,'baik',1),(3,'AC Split 1/2 PK','kamar',2,'perlu_perbaikan',1),(4,'Meja Belajar','kamar',3,'baik',1),(5,'Kompor Gas','area_bersama',NULL,'baik',2),(6,'Wastafel Cuci Piring','area_bersama',NULL,'baik',1),(7,'Mesin Cuci','area_bersama',NULL,'perlu_perbaikan',1),(8,'Tabung APAR','area_bersama',NULL,'baik',1);
/*!40000 ALTER TABLE `inventaris` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kamar`
--

DROP TABLE IF EXISTS `kamar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kamar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomor_kamar` varchar(20) NOT NULL,
  `tipe_kamar` varchar(50) NOT NULL,
  `harga` decimal(10,2) NOT NULL,
  `fasilitas` text NOT NULL,
  `status` enum('tersedia','terisi','maintenance') DEFAULT 'tersedia',
  `foto` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kamar`
--

LOCK TABLES `kamar` WRITE;
/*!40000 ALTER TABLE `kamar` DISABLE KEYS */;
INSERT INTO `kamar` VALUES (2,'01','Large',1400000.00,'Kasur, lemari, Meja Belajar, Wc, AC','terisi','6ad2004aaf258.jpeg'),(3,'02','Large',1400000.00,'Kasur, lemari, Meja Belajar, Wc, AC','tersedia','6ad27930d9d9e.jpeg'),(4,'03','Large',1400000.00,'Kasur, Lemari, Meja Belajar, Kamar Mandi Dalam, AC','tersedia',''),(5,'04','Large',1400000.00,'Kasur, Lemari, Meja Belajar, Kamar Mandi Dalam, AC','tersedia',''),(6,'05','Standar',1100000.00,'Kasur, Lemari, Meja Belajar, Kamar Mandi Luar','tersedia',''),(7,'06','Standar',1100000.00,'Kasur, Lemari, Meja Belajar, Kamar Mandi Luar','maintenance',''),(8,'07','Deluxe',1700000.00,'Kasur, Lemari, Meja Belajar, Kamar Mandi Dalam, AC, Water Heater','terisi',''),(9,'08','Deluxe',1700000.00,'Kasur, Lemari, Meja Belajar, Kamar Mandi Dalam, AC, Water Heater','tersedia','');
/*!40000 ALTER TABLE `kamar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `komplain`
--

DROP TABLE IF EXISTS `komplain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `komplain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `judul_laporan` varchar(150) NOT NULL,
  `deskripsi` text NOT NULL,
  `status_laporan` enum('pending','diproses','selesai') DEFAULT 'pending',
  `tanggal_laporan` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `komplain_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `komplain`
--

LOCK TABLES `komplain` WRITE;
/*!40000 ALTER TABLE `komplain` DISABLE KEYS */;
INSERT INTO `komplain` VALUES (1,7,'ac bocor','ac bocor , air nya netes ke meja','selesai','2026-10-16 16:38:32');
/*!40000 ALTER TABLE `komplain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tagihan`
--

DROP TABLE IF EXISTS `tagihan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tagihan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `kamar_id` int(11) NOT NULL,
  `jenis` enum('dp','sewa_bulanan') NOT NULL DEFAULT 'sewa_bulanan',
  `bulan` varchar(50) NOT NULL,
  `jumlah` decimal(10,2) NOT NULL,
  `jatuh_tempo` date DEFAULT NULL,
  `status_pembayaran` enum('belum_bayar','menunggu_konfirmasi','lunas','ditolak') NOT NULL DEFAULT 'belum_bayar',
  `bukti_bayar` varchar(255) DEFAULT NULL,
  `tanggal_bayar` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `kamar_id` (`kamar_id`),
  CONSTRAINT `tagihan_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tagihan_ibfk_2` FOREIGN KEY (`kamar_id`) REFERENCES `kamar` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tagihan`
--

LOCK TABLES `tagihan` WRITE;
/*!40000 ALTER TABLE `tagihan` DISABLE KEYS */;
INSERT INTO `tagihan` VALUES (7,9,8,'dp','DP / Bulan Pertama',1700000.00,'2026-11-11','belum_bayar',NULL,NULL);
/*!40000 ALTER TABLE `tagihan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `role` enum('admin','user') DEFAULT 'user',
  `status_akun` enum('pending','aktif','ditolak') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `ktp` varchar(255) DEFAULT NULL,
  `id_kamar` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_users_kamar` (`id_kamar`),
  CONSTRAINT `fk_users_kamar` FOREIGN KEY (`id_kamar`) REFERENCES `kamar` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'Administrator Kosmos','admin@kosmos.com','$2y$10$kS.hlQ3jJw5Fv87rKWpJp.KxSsgBkFZ5//SffbdBjTTJa/Jq06cZK','08123456789','admin','aktif','2026-10-16 08:18:04',NULL,NULL),(7,'fadil','rx7ihsanarazi@gmail.com','$2y$10$wraX/8KSB9ClQoI/iKr5S.ljTbVwpjDOMBa9cN5x5CuaGW.PJ0yQa','085176762819','user','aktif','2026-10-16 15:25:31','6ad241eb5e1ac.jpeg',2),(9,'Andika Bagas Febrian','kasir@seduh.test','$2y$10$e8W3sSygq6WPolKitXY38u6c5pX21cNINw9qkazPgyybGorvuC/P2','085603317686','user','aktif','2026-11-04 09:11:43','ktp_6aeaf6cf96ecb.jpg',8);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-04 17:39:05
