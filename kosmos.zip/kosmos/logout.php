<?php
// Mulai session
session_start();

// Hapus semua variabel session
session_unset();

// Hancurkan session-nya
session_destroy();

// Arahkan kembali ke halaman login
header("Location: login.php");
exit;
