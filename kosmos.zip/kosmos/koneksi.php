<?php
// Konfigurasi Database MySQL
$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_kosmos";

// Melakukan koneksi ke database menggunakan MySQLi
$conn = mysqli_connect($host, $user, $pass, $db);

// Cek apakah koneksi berhasil atau gagal
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>