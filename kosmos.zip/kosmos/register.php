<?php
// Panggil file koneksi database
include 'koneksi.php';

// Inisialisasi variabel pesan agar tidak muncul warning saat halaman pertama kali dibuka
$pesan = "";
$kamar_dipilih = isset($_GET['kamar']) && ctype_digit((string) $_GET['kamar']) ? (int) $_GET['kamar'] : 0;

if (isset($_POST['register'])) {
    $nama     = trim($_POST['nama']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $no_hp    = trim($_POST['no_hp']);
    $id_kamar = (int) $_POST['kamar_id'];

    // 1. Sanitasi & validasi input sisi server
    $errors = [];
    if (strlen($nama) < 3 || strlen($nama) > 100) {
        $errors[] = "Nama lengkap minimal 3 karakter.";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Format email tidak valid.";
    }
    if (strlen($password) < 8) {
        $errors[] = "Password minimal 8 karakter.";
    }
    if (!preg_match('/^[0-9]{9,15}$/', $no_hp)) {
        $errors[] = "Nomor WhatsApp harus 9-15 digit tanpa karakter lain.";
    }

    // 2. Kamar harus ada dan masih berstatus tersedia
    if (!$errors) {
        $stmt_kamar = $conn->prepare('SELECT id, harga, status FROM kamar WHERE id = ?');
        $stmt_kamar->bind_param('i', $id_kamar);
        $stmt_kamar->execute();
        $data_kamar = $stmt_kamar->get_result()->fetch_assoc();
        if (!$data_kamar || $data_kamar['status'] !== 'tersedia') {
            $errors[] = "Kamar yang dipilih tidak tersedia. Silakan pilih kamar lain.";
        }
    }

    // 3. Pemeriksaan duplikasi email (prepared statement)
    if (!$errors) {
        $stmt_email = $conn->prepare('SELECT id FROM users WHERE email = ?');
        $stmt_email->bind_param('s', $email);
        $stmt_email->execute();
        if ($stmt_email->get_result()->num_rows > 0) {
            $errors[] = "Email sudah terdaftar! Gunakan email lain.";
        }
    }

    // 4. Validasi berkas KTP: ekstensi, tipe MIME, dan ukuran maksimum 2 MB
    $file_ktp = $_FILES['ktp'] ?? [];
    if (!$errors) {
        if (empty($file_ktp['name'])) {
            $errors[] = "Foto KTP wajib diunggah.";
        } else {
            $ekstensi_diizinkan = ['jpg', 'jpeg', 'png'];
            $mime_diizinkan     = ['image/jpeg', 'image/png'];
            $batas_ukuran       = 2 * 1024 * 1024; // 2 MB

            $ekstensi_file = strtolower(pathinfo($file_ktp['name'], PATHINFO_EXTENSION));
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime_file = $finfo->file($file_ktp['tmp_name']);

            if (!in_array($ekstensi_file, $ekstensi_diizinkan, true) || !in_array($mime_file, $mime_diizinkan, true)) {
                $errors[] = "Foto KTP harus berisi gambar JPG, JPEG, atau PNG.";
            } elseif ($file_ktp['size'] > $batas_ukuran) {
                $errors[] = "Ukuran foto KTP melebihi batas 2 MB.";
            } elseif ($file_ktp['error'] !== UPLOAD_ERR_OK) {
                $errors[] = "Berkas KTP gagal diunggah.";
            }
        }
    }

    if ($errors) {
        $pesan = "<div class='alert'>" . implode('<br>', array_map('htmlspecialchars', $errors)) . "</div>";
    } else {
        // 5. Penyimpanan berkas KTP dengan nama unik
        $dir_tujuan = "uploads/ktp/";
        if (!is_dir($dir_tujuan)) {
            mkdir($dir_tujuan, 0777, true);
        }
        $nama_file_baru = uniqid('ktp_') . '.' . $ekstensi_file;

        if (!move_uploaded_file($file_ktp['tmp_name'], $dir_tujuan . $nama_file_baru)) {
            $pesan = "<div class='alert'>Gagal menyimpan foto KTP. Coba lagi.</div>";
        } else {
            // 6. Hashing kata sandi
            $password_hashed = password_hash($password, PASSWORD_DEFAULT);

            // 7. Simpan akun baru: role penghuni ('user'), status menunggu verifikasi Admin
            $stmt_user = $conn->prepare(
                "INSERT INTO users (nama, email, password, no_hp, id_kamar, ktp, role, status_akun)
                 VALUES (?, ?, ?, ?, ?, ?, 'user', 'pending')"
            );
            $stmt_user->bind_param('ssssis', $nama, $email, $password_hashed, $no_hp, $id_kamar, $nama_file_baru);

            if ($stmt_user->execute()) {
                $user_id_baru = $conn->insert_id;

                // 8. Tagihan DP dibuat otomatis, menunggu konfirmasi pembayaran
                $jatuh_tempo = date('Y-m-d', strtotime('+7 days'));
                $harga_dp    = $data_kamar['harga'];
                $keterangan  = 'DP / Bulan Pertama';
                $stmt_dp = $conn->prepare(
                    "INSERT INTO tagihan (user_id, kamar_id, jenis, bulan, jumlah, jatuh_tempo, status_pembayaran)
                     VALUES (?, ?, 'dp', ?, ?, ?, 'belum_bayar')"
                );
                $stmt_dp->bind_param('iisds', $user_id_baru, $id_kamar, $keterangan, $harga_dp, $jatuh_tempo);
                $stmt_dp->execute();

                $pesan = "<div class='alert alert-ok'>Pendaftaran berhasil! Akun Anda berstatus pending dan menunggu verifikasi admin. Kartu kamar Anda akan ditetapkan setelah diverifikasi.</div>";
                $kamar_dipilih = 0;
            } else {
                $pesan = "<div class='alert'>Gagal menyimpan data ke database. Silakan coba lagi.</div>";
            }
        }
    }
}

// Ambil daftar kamar yang statusnya masih 'tersedia'
$query_kamar_tersedia = $conn->query("SELECT id, nomor_kamar, harga FROM kamar WHERE status = 'tersedia' ORDER BY nomor_kamar ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register - Kosmos</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f0f0;
            color: #111111;
            margin: 0;
            padding: 40px 20px;
        }
        .register-container {
            max-width: 450px;
            background: #ffffff;
            padding: 35px;
            margin: auto;
            border: 2px solid #111111;
            border-radius: 6px;
            box-shadow: 5px 5px 0px #111111;
        }
        h2 {
            text-align: center;
            color: #111111;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }
        label {
            font-weight: 600;
            font-size: 14px;
            color: #333333;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"],
        select {
            width: 100%;
            padding: 10px;
            margin: 6px 0 16px 0;
            border: 1.5px solid #cccccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 14px;
        }
        input:focus, select:focus {
            border-color: #111111;
            outline: none;
        }
        input[type="file"] {
            margin: 6px 0 16px 0;
            font-size: 14px;
        }
        button[type="submit"] {
            width: 100%;
            background: #111111;
            color: #ffffff;
            border: none;
            padding: 12px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            font-size: 15px;
            transition: background 0.2s;
        }
        button[type="submit"]:hover {
            background: #333333;
        }
        .footer-link {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
        }
        .footer-link a {
            color: #111111;
            text-decoration: underline;
            font-weight: bold;
        }
        .alert {
            padding: 12px 14px;
            background: #111;
            color: #fff;
            margin-bottom: 15px;
            border-radius: 4px;
            font-size: 13px;
            line-height: 1.6;
        }
        .alert-ok {
            background: #fff;
            color: #111;
            border: 2px solid #111;
        }
        .hint {
            font-size: 12px;
            color: #666;
            margin: -12px 0 14px 0;
        }
    </style>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <div class="register-container">
        <h2>KOSMOS</h2>
        <p style="text-align: center; color: #666; margin-top: 0; margin-bottom: 25px; font-size: 13px;">Pendaftaran Akun Penyewa Baru</p>
        
        <?= $pesan; ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <label>Nama Lengkap</label>
            <input type="text" name="nama" required>

            <label>Email</label>
            <input type="email" name="email" required>

            <label>Password</label>
            <input type="password" name="password" minlength="8" required>
            <p class="hint">Minimal 8 karakter.</p>

            <label>Nomor WhatsApp</label>
            <input type="text" name="no_hp" pattern="[0-9]{9,15}" required>
            <p class="hint">Contoh: 081234567890.</p>

            <label>Pilih Kamar</label>
            <select name="kamar_id" required>
                <option value="">-- Pilih Kamar Kosong --</option>
                <?php while ($kamar = $query_kamar_tersedia->fetch_assoc()) { ?>
                    <option value="<?= (int) $kamar['id']; ?>" <?= $kamar_dipilih === (int) $kamar['id'] ? 'selected' : ''; ?>>
                        Kamar No. <?= htmlspecialchars($kamar['nomor_kamar']); ?> (Rp <?= number_format($kamar['harga'], 0, ',', '.'); ?>)
                    </option>
                <?php } ?>
            </select>

            <label>Upload Foto KTP (JPG/PNG, maks. 2 MB)</label>
            <input type="file" name="ktp" accept=".jpg,.jpeg,.png,image/jpeg,image/png" required>

            <button type="submit" name="register">DAFTAR SEKARANG</button>
        </form>

        <div class="footer-link">
            Sudah punya akun? <a href="login.php">Login di sini</a>
        </div>
    </div>

</body>
</html>
