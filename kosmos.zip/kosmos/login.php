<?php
// Mulai session PHP
session_start();
include 'koneksi.php';

$pesan = "";

if (isset($_POST['login'])) {
    $email    = trim($_POST['email']);
    $password = $_POST['password'];

    $pesan_error = "<div class='alert'>Email atau password salah.</div>";

    if ($email === '' || $password === '') {
        $pesan = "<div class='alert'>Email dan password wajib diisi.</div>";
    } else {
        // 1. Ambil data pengguna berdasarkan email (prepared statement)
        $stmt = $conn->prepare('SELECT * FROM users WHERE email = ?');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        // 2. Verifikasi kata sandi terhadap hash
        if ($row && password_verify($password, $row['password'])) {
            $aktif = ($row['status_akun'] === 'aktif' || $row['role'] === 'admin');

            if (!$aktif) {
                // 3a. Akun belum aktif: tampilkan info menunggu verifikasi
                $info = $row['status_akun'] === 'ditolak'
                    ? "Pendaftaran Anda ditolak admin. Silakan hubungi pengelola kos."
                    : "Akun Anda masih dalam status 'pending' (menunggu verifikasi admin). Harap sabar menunggu!";
                $pesan = "<div class='alert'>$info</div>";
            } else {
                // 3b. Simpan identitas ke sesi dan arahkan sesuai peran (RBAC)
                session_regenerate_id(true);
                $_SESSION['login']   = true;
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['nama']    = $row['nama'];
                $_SESSION['role']    = $row['role'];

                if ($row['role'] == 'admin') {
                    header("Location: admin/dashboard.php");
                    exit;
                }
                header("Location: user/dashboard.php");
                exit;
            }
        } else {
            // Pesan sengaja dibuat umum: tidak membedakan email tidak dikenal
            // dan password salah, agar tidak membocorkan akun yang terdaftar.
            $pesan = $pesan_error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - Kosmos</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f0f0;
            color: #111111;
            margin: 0;
            padding: 60px 20px;
        }
        .login-container {
            max-width: 400px;
            background: #ffffff;
            padding: 35px;
            margin: auto;
            border: 2px solid #111111;
            border-radius: 6px;
            box-shadow: 5px 5px 0px #111111;
        }
        h2 {
            text-align: center;
            color: #111111;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }
        label {
            font-weight: 600;
            font-size: 14px;
            color: #333333;
        }
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 6px 0 16px 0;
            border: 1.5px solid #cccccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 14px;
        }
        input:focus {
            border-color: #111111;
            outline: none;
        }
        button[type="submit"] {
            width: 100%;
            background: #111111;
            color: #ffffff;
            border: none;
            padding: 12px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            font-size: 15px;
            transition: background 0.2s;
        }
        button[type="submit"]:hover {
            background: #333333;
        }
        .footer-link {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
        }
        .footer-link a {
            color: #111111;
            text-decoration: underline;
            font-weight: bold;
        }
        .alert {
            padding: 12px 14px;
            background: #111;
            color: #fff;
            margin-bottom: 15px;
            border-radius: 4px;
            font-size: 13px;
            line-height: 1.6;
        }
    </style>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <div class="login-container">
        <h2>KOSMOS</h2>
        <p style="text-align: center; color: #666; margin-top: 0; margin-bottom: 25px; font-size: 13px;">Silakan masuk ke akun Anda</p>
        
        <?= $pesan; ?>

        <form action="" method="POST">
            <label>Email</label>
            <input type="email" name="email" required>

            <label>Password</label>
            <input type="password" name="password" required>

            <button type="submit" name="login">LOGIN</button>
        </form>

        <div class="footer-link">
            Belum punya akun? <a href="register.php">Daftar di sini</a>
        </div>
    </div>

</body>
</html>