<?php
session_start();
include 'koneksi.php';

// ==== Filter katalog (FR-02) ====
// Parameter dibaca dari $_GET, divalidasi, lalu dipasang sebagai kondisi WHERE
// melalui prepared statement + bind_param agar bebas dari SQL Injection.
$status_filter = $_GET['status'] ?? '';
$harga_min     = $_GET['harga_min'] ?? '';
$harga_max     = $_GET['harga_max'] ?? '';

$status_valid  = ['tersedia', 'terisi', 'maintenance'];
if ($status_filter !== '' && !in_array($status_filter, $status_valid, true)) {
    $status_filter = '';
}
if ($harga_min !== '' && !is_numeric($harga_min)) { $harga_min = ''; }
if ($harga_max !== '' && !is_numeric($harga_max)) { $harga_max = ''; }

$sql    = 'SELECT * FROM kamar WHERE 1=1';
$params = [];
$types  = '';

if ($status_filter !== '') {
    $sql   .= ' AND status = ?';
    $types .= 's';
    $params[] = &$status_filter;
}
if ($harga_min !== '') {
    $harga_min = (float) $harga_min;
    $sql      .= ' AND harga >= ?';
    $types    .= 'd';
    $params[] = &$harga_min;
}
if ($harga_max !== '') {
    $harga_max = (float) $harga_max;
    $sql      .= ' AND harga <= ?';
    $types    .= 'd';
    $params[] = &$harga_max;
}
$sql .= ' ORDER BY nomor_kamar ASC';

$stmt = $conn->prepare($sql);
if ($types !== '') {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$query_katalog = $stmt->get_result();
$jumlah_kamar  = $query_katalog->num_rows;

// Total kamar tanpa filter, untuk keterangan ringkas
$total_semua = $conn->query('SELECT COUNT(*) AS total FROM kamar')->fetch_assoc()['total'];

$ada_filter = ($status_filter !== '' || $harga_min !== '' || $harga_max !== '');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Katalog Kamar - Kosmos</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #111111;
            margin: 0;
            padding: 0;
        }

        /* Navbar Header */
        .navbar {
            background: #111111;
            color: #ffffff;
            padding: 18px 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar h1 {
            margin: 0;
            font-size: 22px;
            letter-spacing: 2px;
        }
        .nav-links a {
            color: #ffffff;
            text-decoration: none;
            margin-left: 20px;
            font-size: 14px;
            font-weight: 500;
        }
        .nav-links a.btn-login {
            background: #ffffff;
            color: #111111;
            padding: 8px 18px;
            border-radius: 4px;
            font-weight: bold;
        }
        .nav-links a.btn-login:hover {
            background: #cccccc;
        }

        /* Container Katalog */
        .container {
            max-width: 1000px;
            margin: 40px auto;
            padding: 0 20px;
        }
        .header-title {
            text-align: center;
            margin-bottom: 40px;
        }
        .header-title h2 {
            font-size: 32px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 10px;
        }
        .header-title p {
            color: #666;
            font-size: 15px;
        }

        .katalog-grid {
            display: flex;
            gap: 25px;
            justify-content: center;
            flex-wrap: wrap;
        }
        .katalog-card {
            background: #ffffff;
            border: 2px solid #111111;
            border-radius: 6px;
            width: 300px;
            overflow: hidden;
            box-shadow: 4px 4px 0px #111111;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .katalog-card img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            border-bottom: 2px solid #111111;
        }
        .card-content {
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            flex: 1;
        }
        .katalog-card h3 {
            margin-top: 0;
            font-size: 20px;
            border-bottom: 1px solid #eee;
            padding-bottom: 8px;
        }
        .badge-status {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: bold;
            text-transform: uppercase;
            margin-bottom: 10px;
        }
        .harga {
            font-size: 18px;
            font-weight: bold;
            margin: 10px 0;
        }
        .fasilitas {
            font-size: 13px;
            color: #555;
            margin-bottom: 20px;
            line-height: 1.5;
        }
        .btn-pesan {
            display: block;
            text-align: center;
            background: #111111;
            color: #ffffff;
            text-decoration: none;
            padding: 12px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 13px;
            transition: background 0.2s;
        }
        .btn-pesan:hover {
            background: #333333;
        }

        /* Footer */
        .footer {
            background: #111111;
            color: #888888;
            text-align: center;
            padding: 20px;
            font-size: 13px;
            margin-top: 60px;
        }
    </style>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <!-- Navbar Header -->
    <div class="navbar">
        <h1>KOSMOS</h1>
        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="katalog-kamar.php">Katalog Kamar</a>
            <?php if (isset($_SESSION['login'])) { ?>
                <?php if ($_SESSION['role'] == 'admin') { ?>
                    <a href="admin/dashboard.php" class="btn-login">Dashboard Admin</a>
                    <a href="logout.php">Logout</a>
                <?php } else { ?>
                    <a href="user/dashboard.php" class="btn-login">Dashboard Saya</a>
                    <a href="logout.php">Logout</a>
                <?php } ?>
            <?php } else { ?>
                <a href="register.php">Daftar</a>
                <a href="login.php" class="btn-login">Login</a>
            <?php } ?>
        </div>
    </div>

    <!-- Konten Katalog -->
    <div class="container">
        <div class="header-title">
            <h2>Katalog Seluruh Kamar</h2>
            <p>Pilih kamar yang sesuai dengan kenyamanan dan kebutuhan Anda di Kosmos.</p>
        </div>

        <!-- Form Filter: status ketersediaan + rentang harga sewa -->
        <form class="filter-form" method="GET" action="katalog-kamar.php">
            <div class="filter-field">
                <label for="status">Status Kamar</label>
                <select name="status" id="status">
                    <option value="">Semua Status</option>
                    <option value="tersedia" <?= $status_filter === 'tersedia' ? 'selected' : ''; ?>>Tersedia</option>
                    <option value="terisi" <?= $status_filter === 'terisi' ? 'selected' : ''; ?>>Terisi</option>
                    <option value="maintenance" <?= $status_filter === 'maintenance' ? 'selected' : ''; ?>>Maintenance</option>
                </select>
            </div>
            <div class="filter-field">
                <label for="harga_min">Harga Minimum (Rp)</label>
                <input type="number" name="harga_min" id="harga_min" min="0" step="50000"
                       value="<?= htmlspecialchars($harga_min); ?>" placeholder="mis. 1000000">
            </div>
            <div class="filter-field">
                <label for="harga_max">Harga Maksimum (Rp)</label>
                <input type="number" name="harga_max" id="harga_max" min="0" step="50000"
                       value="<?= htmlspecialchars($harga_max); ?>" placeholder="mis. 1500000">
            </div>
            <button type="submit">TERAPKAN FILTER</button>
            <?php if ($ada_filter) { ?>
                <a href="katalog-kamar.php" class="reset">Reset</a>
            <?php } ?>
        </form>

        <p class="filter-summary">
            Menampilkan <strong><?= $jumlah_kamar; ?></strong> dari <strong><?= $total_semua; ?></strong> kamar
            <?= $ada_filter ? '(hasil filter)' : '(tanpa filter)'; ?>.
        </p>

        <div class="katalog-grid">
            <?php if ($jumlah_kamar > 0) { ?>
                <?php while ($row = $query_katalog->fetch_assoc()) { ?>
                    <div class="katalog-card">
                        <?php 
                        $foto_kamar = (!empty($row['foto']) && file_exists("uploads/kamar/" . $row['foto'])) ? "uploads/kamar/" . $row['foto'] : "assets/img/kamar1.jpeg"; 
                        ?>
                        <img src="<?= htmlspecialchars($foto_kamar); ?>" alt="Foto Kamar">

                        <div class="card-content">
                            <div>
                                <h3>Kamar No. <?= htmlspecialchars($row['nomor_kamar']); ?></h3>
                                
                                <!-- Badge Status Kamar -->
                                <?php if ($row['status'] == 'tersedia') { ?>
                                    <span class="badge-status" style="background: #111; color: #fff;">Tersedia</span>
                                <?php } elseif ($row['status'] == 'terisi') { ?>
                                    <span class="badge-status" style="background: #ddd; color: #333;">Terisi</span>
                                <?php } else { ?>
                                    <span class="badge-status" style="background: #666; color: #fff;">Maintenance</span>
                                <?php } ?>

                                <p style="font-size: 13px; color: #666; margin: 0 0 10px 0;"><strong>Tipe:</strong> <?= htmlspecialchars($row['tipe_kamar']); ?></p>
                                <div class="harga">Rp <?= number_format($row['harga'], 0, ',', '.'); ?> <span style="font-size: 12px; font-weight: normal; color: #666;">/ bulan</span></div>
                                <div class="fasilitas">
                                    <strong>Fasilitas:</strong><br>
                                    <?= htmlspecialchars($row['fasilitas']); ?>
                                </div>
                            </div>

                            <div>
                                <!-- Tombol mengarah ke detail-kamar.php dengan membawa ID kamar -->
                                <a href="detail-kamar.php?id=<?= (int) $row['id']; ?>" class="btn-pesan">LIHAT DETAIL KAMAR</a>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <div class="empty-state">
                    <strong>Kamar tidak ditemukan.</strong><br>
                    Tidak ada kamar yang cocok dengan kombinasi filter yang dipilih.
                    <a href="katalog-kamar.php" style="color:#111; font-weight:bold;">Kembalikan tampilan semua kamar</a>
                </div>
            <?php } ?>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        &copy; <?= date('Y'); ?> Kosmos - Kost Management System. All rights reserved.
    </div>

</body>
</html>
