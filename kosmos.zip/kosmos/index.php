<?php
session_start();
include 'koneksi.php';

// Ambil beberapa data kamar untuk ditampilkan di halaman depan
$stmt_kamar = $conn->prepare("SELECT * FROM kamar WHERE status = 'tersedia' ORDER BY nomor_kamar ASC LIMIT 3");
$stmt_kamar->execute();
$query_kamar = $stmt_kamar->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kosmos - Sistem Manajemen Kos</title>
    <style>
        /* CSS INTERNAL UTAMA */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f0f0;
            color: #111111;
            margin: 0;
            padding: 0;
        }

        /* Navbar Sederhana */
        .navbar {
            background-color: #111111;
            color: #ffffff;
            padding: 15px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar h1 {
            font-size: 20px;
            margin: 0;
            letter-spacing: 1px;
        }
        .navbar-links a {
            color: #ffffff;
            text-decoration: none;
            margin-left: 20px;
            font-size: 14px;
            font-weight: 600;
        }
        .navbar-links a:hover {
            text-decoration: underline;
        }
        .btn-dashboard {
            background: #ffffff;
            color: #111111 !important;
            padding: 6px 12px;
            border-radius: 4px;
        }

        /* KONTEN 1: HERO SECTION */
        .hero-section {
            background-color: #ffffff;
            padding: 70px 20px;
            text-align: center;
            border-bottom: 2px solid #111111;
        }
        .hero-section h2 {
            font-size: 32px;
            font-weight: 900;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .hero-section p {
            font-size: 15px;
            color: #555555;
            margin-bottom: 25px;
        }
        .btn-main {
            background: #111111;
            color: #ffffff;
            padding: 10px 20px;
            text-decoration: none;
            font-weight: bold;
            border-radius: 4px;
            display: inline-block;
            border: 2px solid #111111;
        }
        .btn-main:hover {
            background: #333333;
        }

        /* KONTEN 2: KAMAR PILIHAN */
        .room-section {
            padding: 50px 20px;
            text-align: center;
        }
        .room-section h2 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 30px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .room-grid {
            display: flex;
            justify-content: center;
            gap: 25px;
            flex-wrap: wrap;
            max-width: 1100px;
            margin: 0 auto;
        }
        .room-card {
            background: #ffffff;
            width: 280px;
            border: 2px solid #111111;
            border-radius: 6px;
            box-shadow: 4px 4px 0px #111111;
            overflow: hidden;
            text-align: left;
            display: flex;
            flex-direction: column;
        }
        .room-img {
            width: 100%;
            height: 170px;
            object-fit: cover;
            border-bottom: 2px solid #111111;
            background-color: #ddd;
        }
        .room-body {
            padding: 15px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .room-body h3 {
            font-size: 16px;
            margin: 0 0 5px 0;
            font-weight: bold;
        }
        .room-body p {
            font-size: 13px;
            color: #555;
            margin: 4px 0;
        }
        .btn-card {
            display: block;
            background: #111111;
            color: #ffffff;
            text-align: center;
            padding: 8px;
            text-decoration: none;
            font-weight: bold;
            font-size: 13px;
            border-radius: 4px;
            margin-top: 15px;
        }
        .btn-card:hover {
            background: #333333;
        }

        /* KONTEN 3: FASILITAS EKSTERNAL (Lebih Mengkotak / Square Card) */
        .facility-section {
            padding: 50px 20px;
            background-color: #e8e8e8;
            text-align: center;
            border-top: 2px solid #111111;
            border-bottom: 2px solid #111111;
        }
        .facility-section h2 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 30px;
            color: #111111;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .facility-grid {
            display: flex;
            justify-content: center;
            gap: 25px;
            flex-wrap: wrap;
            max-width: 1000px;
            margin: 0 auto;
        }
        .facility-card {
            background: #ffffff;
            width: 280px;
            border: 2px solid #111111;
            border-radius: 6px;
            box-shadow: 4px 4px 0px #111111;
            overflow: hidden;
            text-align: left;
            display: flex;
            flex-direction: column;
        }
        .facility-img-box {
            width: 100%;
            height: 180px; /* Bentuk lebih mengkotak proporsional */
            background-color: #ddd;
            border-bottom: 2px solid #111111;
        }
        .facility-img-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .facility-body {
            padding: 20px;
        }
        .facility-body h3 {
            font-size: 16px;
            font-weight: bold;
            margin: 0 0 8px 0;
            color: #111111;
        }
        .facility-body p {
            font-size: 13px;
            color: #555555;
            margin: 0;
            line-height: 1.4;
        }

        /* Footer Sederhana */
        footer {
            background: #111111;
            color: #ffffff;
            text-align: center;
            padding: 20px;
            font-size: 13px;
        }
    </style>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <div class="navbar">
        <h1>KOSMOS</h1>
        <div class="navbar-links">
            <a href="index.php">Home</a>
            <a href="katalog-kamar.php">Katalog Kamar</a>
            <?php if (isset($_SESSION['login'])) { ?>
                <?php if ($_SESSION['role'] == 'admin') { ?>
                    <a href="admin/dashboard.php" class="btn-dashboard">Dashboard Admin</a>
                <?php } else { ?>
                    <a href="user/dashboard.php" class="btn-dashboard">Dashboard Saya</a>
                <?php } ?>
                <a href="logout.php">Logout</a>
            <?php } else { ?>
                <a href="register.php">Daftar</a>
                <a href="login.php" class="btn-dashboard">Login</a>
            <?php } ?>
        </div>
    </div>

    <!-- KONTEN 1: HERO SECTION -->
    <div class="hero-section">
        <h2>HUNIAN NYAMAN & MINIMALIS</h2>
        <p>Sistem Manajemen Kos Terpadu. Cari kamar kosong, daftar secara online, dan kelola pembayaran tanpa ribet.</p>
        <a href="katalog-kamar.php" class="btn-main">LIHAT KATALOG KAMAR</a>
    </div>

    <!-- KONTEN 2: KAMAR PILIHAN TERSEDIA -->
    <div class="room-section">
        <h2>Kamar Pilihan Tersedia</h2>
        <div class="room-grid">
            <?php 
            if ($query_kamar->num_rows > 0) {
                while ($kamar = $query_kamar->fetch_assoc()) {
                    $foto = (!empty($kamar['foto']) && file_exists("uploads/kamar/" . $kamar['foto']))
                        ? "uploads/kamar/" . $kamar['foto'] : "assets/img/kamar1.jpeg";
            ?>
            <div class="room-card">
                <img src="<?= htmlspecialchars($foto); ?>" alt="Kamar" class="room-img">
                <div class="room-body">
                    <div>
                        <h3>Kamar No. <?= htmlspecialchars($kamar['nomor_kamar']); ?></h3>
                        <p><strong>Tipe:</strong> <?= htmlspecialchars($kamar['tipe_kamar']); ?></p>
                        <p style="font-weight: bold; color: #111;">Rp <?= number_format($kamar['harga'], 0, ',', '.'); ?> <span style="font-size: 11px; font-weight: normal; color: #666;">/ bulan</span></p>
                        <p><strong>Fasilitas:</strong> <?= htmlspecialchars($kamar['fasilitas']); ?></p>
                    </div>
                    <a href="detail-kamar.php?id=<?= (int) $kamar['id']; ?>" class="btn-card">LIHAT DETAIL</a>
                    <a href="register.php?kamar=<?= (int) $kamar['id']; ?>" class="btn-card" style="margin-top: 8px;">PESAN SEKARANG</a>
                </div>
            </div>
            <?php 
                }
            } else { 
            ?>
                <p style="color: #666;">Belum ada kamar kosong yang tersedia saat ini.</p>
            <?php } ?>
        </div>
    </div>

    <!-- KONTEN 3: FASILITAS EKSTERNAL / BERSAMA -->
    <div class="facility-section">
        <h2>Fasilitas Eksternal</h2>
        <div class="facility-grid">
            
            <!-- Fasilitas 1: Dapur -->
            <div class="facility-card">
                <div class="facility-img-box">
                    <img src="assets/img/dapur.jpeg" alt="Dapur Bersama" onerror="this.style.display='none'">
                </div>
                <div class="facility-body">
                    <h3>Dapur Bersama</h3>
                    <p>Dilengkapi kompor gas, wastafel cuci piring, dan area memasak bersama yang bersih dan nyaman.</p>
                </div>
            </div>

            <!-- Fasilitas 2: Ruang Cuci -->
            <div class="facility-card">
                <div class="facility-img-box">
                    <img src="assets/img/cuci.jpg" alt="Ruang Cuci Jemur" onerror="this.style.display='none'">
                </div>
                <div class="facility-body">
                    <h3>Ruang Cuci & Jemur</h3>
                    <p>Area khusus mencuci pakaian dan tempat penjemuran luas dengan sirkulasi udara yang baik.</p>
                </div>
            </div>

            <!-- Fasilitas 3: Keamanan -->
            <div class="facility-card">
                <div class="facility-img-box">
                    <img src="assets/img/keamanan.jpg" alt="Keamanan 24 Jam" onerror="this.style.display='none'">
                </div>
                <div class="facility-body">
                    <h3>Keamanan Kamar</h3>
                    <p>Dilengkapi Screen Lock digital yang terkunci aman untuk menjaga keamanan penghuni.</p>
                </div>
            </div>

        </div>
    </div>

    <!-- FOOTER -->
    <footer>
        <p>&copy; 2026 Kosmos. All Rights Reserved.</p>
    </footer>

</body>
</html>