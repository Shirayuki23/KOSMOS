<?php
session_start();
include '../koneksi.php';

// Proteksi Halaman User
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit;
}

$user_id = (int)$_SESSION['user_id'];
$pesan = "";

// PROSES UPLOAD BUKTI PEMBAYARAN
if (isset($_POST['upload_bukti'])) {
    $tagihan_id  = (int)$_POST['tagihan_id'];
    $nama_asli   = $_FILES['bukti']['name'] ?? '';
    $tmp_file    = $_FILES['bukti']['tmp_name'] ?? '';
    $dir_tujuan  = "../uploads/pembayaran/";

    $ukuran_maks = 2 * 1024 * 1024;
    $ekstensi_diizinkan = ['jpg', 'jpeg', 'png', 'pdf'];
    $mime_diizinkan     = ['image/jpeg', 'image/png', 'application/pdf'];

    $ekstensi_file = strtolower(pathinfo($nama_asli, PATHINFO_EXTENSION));
    $finfo   = new finfo(FILEINFO_MIME_TYPE);
    $mime    = $tmp_file ? $finfo->file($tmp_file) : '';
    $ukuran  = isset($_FILES['bukti']['size']) ? (int)$_FILES['bukti']['size'] : 0;

    // Tagihan harus milik penyewa yang sedang login dan belum lunas
    $stmt = $conn->prepare("SELECT * FROM tagihan WHERE id = ? AND user_id = ? AND status_pembayaran != 'lunas'");
    $stmt->bind_param('ii', $tagihan_id, $user_id);
    $stmt->execute();
    $d_tagihan = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$d_tagihan) {
        $pesan = "<div class='alert'>Tagihan tidak ditemukan atau sudah lunas.</div>";
    } elseif ($_FILES['bukti']['error'] !== UPLOAD_ERR_OK) {
        $pesan = "<div class='alert'>Berkas gagal diunggah. Coba lagi.</div>";
    } elseif (!in_array($ekstensi_file, $ekstensi_diizinkan) || !in_array($mime, $mime_diizinkan)) {
        $pesan = "<div class='alert'>Format berkas harus JPG, PNG, atau PDF dan isinya sesuai format tersebut.</div>";
    } elseif ($ukuran > $ukuran_maks) {
        $pesan = "<div class='alert'>Ukuran berkas maksimal 2 MB.</div>";
    } else {
        if (!is_dir($dir_tujuan)) mkdir($dir_tujuan, 0777, true);

        $nama_file_baru = uniqid('bukti_') . '.' . $ekstensi_file;
        if (!move_uploaded_file($tmp_file, $dir_tujuan . $nama_file_baru)) {
            $pesan = "<div class='alert'>Gagal menyimpan berkas bukti bayar.</div>";
        } else {
            // Hapus bukti lama agar tidak menumpuk di folder uploads
            if (!empty($d_tagihan['bukti_bayar']) && is_file($dir_tujuan . $d_tagihan['bukti_bayar'])) {
                unlink($dir_tujuan . $d_tagihan['bukti_bayar']);
            }
            $stmt = $conn->prepare("UPDATE tagihan SET bukti_bayar = ?, status_pembayaran = 'menunggu_konfirmasi' WHERE id = ? AND user_id = ?");
            $stmt->bind_param('sii', $nama_file_baru, $tagihan_id, $user_id);
            if ($stmt->execute()) {
                $pesan = "<div class='alert'>Bukti pembayaran berhasil diunggah. Menunggu konfirmasi admin.</div>";
            } else {
                $pesan = "<div class='alert'>Berkas tersimpan, tetapi status tagihan gagal diperbarui.</div>";
            }
            $stmt->close();
        }
    }
}

// Ambil daftar tagihan milik user yang sedang login
$stmt_tagihan = $conn->prepare(
    "SELECT tagihan.*, kamar.nomor_kamar
     FROM tagihan
     JOIN kamar ON tagihan.kamar_id = kamar.id
     WHERE tagihan.user_id = ?
     ORDER BY tagihan.id DESC"
);
$stmt_tagihan->bind_param('i', $user_id);
$stmt_tagihan->execute();
$query_tagihan = $stmt_tagihan->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tagihan Saya - Kosmos</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f0f0; color: #111111; margin: 0; padding: 0; }
        .sidebar { width: 250px; background: #111111; color: #ffffff; position: fixed; height: 100%; padding: 20px; box-sizing: border-box; }
        .sidebar h2 { font-size: 20px; letter-spacing: 1px; text-align: center; margin-bottom: 30px; border-bottom: 1px solid #444; padding-bottom: 15px; }
        .sidebar a { display: block; color: #ffffff; text-decoration: none; padding: 10px 15px; margin-bottom: 8px; border-radius: 4px; font-size: 14px; transition: background 0.2s; }
        .sidebar a:hover, .sidebar a.active { background: #333333; }
        .sidebar a.logout { background: #ffffff; color: #111111; font-weight: bold; text-align: center; margin-top: 40px; }
        .main-content { margin-left: 250px; padding: 40px; box-sizing: border-box; }
        .card-table { background: #ffffff; padding: 25px; border: 2px solid #111111; border-radius: 6px; box-shadow: 4px 4px 0px #111111; }
        h2 { margin-top: 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #111111; padding: 10px; text-align: left; font-size: 14px; vertical-align: middle; }
        th { background: #111111; color: #ffffff; }
        input[type="file"] { font-size: 12px; margin-bottom: 5px; }
        button[type="submit"] { background: #111111; color: #ffffff; border: none; padding: 6px 12px; border-radius: 3px; cursor: pointer; font-weight: bold; font-size: 12px; }
        button[type="submit"]:hover { background: #333333; }
        .badge { padding: 4px 8px; border-radius: 3px; font-size: 11px; font-weight: bold; text-transform: uppercase; white-space: nowrap; }
        .alert { padding: 12px 15px; background: #111; color: #fff; margin-bottom: 15px; border-radius: 4px; font-size: 13px; }
        .catatan { background: #fff; border: 2px solid #111; border-radius: 6px; box-shadow: 4px 4px 0 #111; padding: 15px 20px; margin-bottom: 25px; font-size: 13px; color: #444; }
    </style>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

    <!-- Sidebar Penyewa -->
    <div class="sidebar">
        <h2>KOSMOS PENYEWA</h2>
        <a href="dashboard.php">Dashboard Saya</a>
        <a href="tagihan-saya.php" class="active">Tagihan Saya</a>
        <a href="inventaris.php">Inventaris Saya</a>
        <a href="lapor-kerusakan.php">Lapor Kerusakan</a>
        <a href="../logout.php" class="logout">LOGOUT</a>
    </div>

    <!-- Konten Utama -->
    <div class="main-content">
        <h1>Riwayat Tagihan & Pembayaran</h1>
        <p style="color: #666; margin-bottom: 25px;">Daftar tagihan kamar kos Anda beserta status pembayarannya.</p>

        <?= $pesan; ?>

        <div class="catatan">
            Unggah bukti transfer (JPG/PNG/PDF, maksimal 2 MB) pada tagihan berstatus <strong>Belum Bayar</strong> atau <strong>Ditolak</strong>.
            Status berubah menjadi <strong>Lunas</strong> setelah admin memverifikasi berkas Anda.
        </div>

        <div class="card-table">
            <h2>Daftar Tagihan</h2>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Jenis & Keterangan</th>
                        <th>Kamar</th>
                        <th>Jumlah</th>
                        <th>Jatuh Tempo</th>
                        <th>Status Pembayaran</th>
                        <th>Aksi / Upload Bukti</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    if ($query_tagihan && $query_tagihan->num_rows > 0) {
                        while ($row = $query_tagihan->fetch_assoc()) { 
                            $status_bg = [
                                'lunas'                 => '#111; color:#fff;',
                                'menunggu_konfirmasi'   => '#eee; color:#333; border:1px solid #111;',
                                'ditolak'               => '#ccc; color:#333;',
                                'belum_bayar'           => '#fff; color:#111; border:1px solid #111;',
                            ];
                            $bukti = $row['bukti_bayar'];
                            $url_bukti = (!empty($bukti) && is_file('../uploads/pembayaran/' . $bukti))
                                ? '../uploads/pembayaran/' . htmlspecialchars(rawurlencode($bukti)) : '';
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td>
                            <span class="badge" style="background:#eee; color:#333; border:1px solid #111;"><?= strtoupper(str_replace('_', ' ', $row['jenis'])); ?></span><br>
                            <strong><?= htmlspecialchars($row['bulan']); ?></strong>
                        </td>
                        <td>Kamar No. <?= htmlspecialchars($row['nomor_kamar']); ?></td>
                        <td>Rp <?= number_format($row['jumlah'], 0, ',', '.'); ?></td>
                        <td>
                            <?= $row['jatuh_tempo'] ? htmlspecialchars($row['jatuh_tempo']) : '<span style="color:#666;">-</span>'; ?>
                            <?php if ($row['tanggal_bayar']) { ?><br><span style="font-size:11px; color:#666;">Dibayar: <?= htmlspecialchars($row['tanggal_bayar']); ?></span><?php } ?>
                        </td>
                        <td>
                            <span class="badge" style="background:<?= $status_bg[$row['status_pembayaran']] ?? '#fff; color:#111; border:1px solid #111;' ?>">
                                <?= strtoupper(str_replace('_', ' ', $row['status_pembayaran'])); ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($row['status_pembayaran'] != 'lunas') { ?>
                                <form action="" method="POST" enctype="multipart/form-data" style="margin: 0;">
                                    <input type="hidden" name="tagihan_id" value="<?= (int)$row['id']; ?>">
                                    <input type="file" name="bukti" accept=".jpg,.jpeg,.png,.pdf" required style="display: block;"><br>
                                    <button type="submit" name="upload_bukti">Upload Bukti</button>
                                </form>
                                <?php if ($url_bukti) { ?>
                                    <br><a href="<?= $url_bukti; ?>" target="_blank" style="font-size: 12px; color: #111; text-decoration: underline;">Lihat Bukti Terupload</a>
                                <?php } elseif (!empty($bukti)) { ?>
                                    <br><span style="font-size: 11px; color: #666;">Berkas bukti tidak ditemukan di server.</span>
                                <?php } ?>
                            <?php } else { ?>
                                <span style="font-weight: bold; font-size: 13px;">Lunas / Selesai</span>
                            <?php } ?>
                        </td>
                    </tr>
                    <?php 
                        }
                    } else { 
                    ?>
                    <tr>
                        <td colspan="7" class="empty-state">Belum ada tagihan untuk Anda.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>
