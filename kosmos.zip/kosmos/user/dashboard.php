<?php
session_start();
include '../koneksi.php';

// Proteksi Halaman: Cek apakah sudah login dan rolenya adalah user
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit;
}

$user_id = (int)$_SESSION['user_id'];

// Data kamar yang menempati penyewa ini
$stmt_kamar = $conn->prepare(
    "SELECT kamar.* FROM users JOIN kamar ON users.id_kamar = kamar.id WHERE users.id = ?"
);
$stmt_kamar->bind_param('i', $user_id);
$stmt_kamar->execute();
$data_kamar = $stmt_kamar->get_result()->fetch_assoc();
$stmt_kamar->close();

// Tagihan aktif terbaru milik penyewa ini
$stmt_tagihan = $conn->prepare(
    "SELECT * FROM tagihan WHERE user_id = ? ORDER BY FIELD(status_pembayaran,'belum_bayar','menunggu_konfirmasi','ditolak','lunas'), id DESC LIMIT 1"
);
$stmt_tagihan->bind_param('i', $user_id);
$stmt_tagihan->execute();
$data_tagihan = $stmt_tagihan->get_result()->fetch_assoc();
$stmt_tagihan->close();

// Ringkasan pembayaran
$stmt_rekap = $conn->prepare(
    "SELECT COUNT(*) AS jumlah_tagihan,
            SUM(status_pembayaran = 'lunas') AS jumlah_lunas,
            COALESCE(SUM(CASE WHEN status_pembayaran != 'lunas' THEN jumlah ELSE 0 END), 0) AS total_tagihan
     FROM tagihan WHERE user_id = ?"
);
$stmt_rekap->bind_param('i', $user_id);
$stmt_rekap->execute();
$data_rekap = $stmt_rekap->get_result()->fetch_assoc();
$stmt_rekap->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Penyewa - Kosmos</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f0f0;
            color: #111111;
            margin: 0;
            padding: 0;
        }
        .sidebar {
            width: 250px;
            background: #111111;
            color: #ffffff;
            position: fixed;
            height: 100%;
            padding: 20px;
            box-sizing: border-box;
        }
        .sidebar h2 {
            font-size: 20px;
            letter-spacing: 1px;
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 1px solid #444;
            padding-bottom: 15px;
        }
        .sidebar a {
            display: block;
            color: #ffffff;
            text-decoration: none;
            padding: 10px 15px;
            margin-bottom: 8px;
            border-radius: 4px;
            font-size: 14px;
            transition: background 0.2s;
        }
        .sidebar a:hover, .sidebar a.active {
            background: #333333;
        }
        .sidebar a.logout {
            background: #ffffff;
            color: #111111;
            font-weight: bold;
            text-align: center;
            margin-top: 40px;
        }
        .main-content {
            margin-left: 250px;
            padding: 40px;
            box-sizing: border-box;
        }
        .header-top {
            background: #ffffff;
            padding: 20px 30px;
            border: 2px solid #111111;
            border-radius: 6px;
            margin-bottom: 30px;
            box-shadow: 4px 4px 0px #111111;
        }
        .cards-container {
            display: flex;
            gap: 20px;
        }
        .card {
            flex: 1;
            background: #ffffff;
            padding: 25px;
            border: 2px solid #111111;
            border-radius: 6px;
            box-shadow: 4px 4px 0px #111111;
        }
        .card h3 {
            margin: 0 0 10px 0;
            font-size: 14px;
            color: #666;
            text-transform: uppercase;
        }
        .badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
            background: #111111;
            color: #ffffff;
        }
    </style>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

    <!-- Sidebar Penyewa -->
    <div class="sidebar">
        <h2>KOSMOS PENYEWA</h2>
        <a href="dashboard.php" class="active">Dashboard Saya</a>
        <a href="tagihan-saya.php">Tagihan Saya</a>
        <a href="inventaris.php">Inventaris Saya</a>
        <a href="lapor-kerusakan.php">Lapor Kerusakan</a>
        <a href="../logout.php" class="logout">LOGOUT</a>
    </div>

    <!-- Konten Utama -->
    <div class="main-content">
        <div class="header-top">
            <h1 style="margin: 0; font-size: 24px;">Selamat Datang, <?= htmlspecialchars($_SESSION['nama']); ?>!</h1>
            <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">Panel khusus penghuni kos Kosmos.</p>
        </div>

        <h2>Informasi Sewa Anda</h2>
        <div class="cards-container">
            <!-- Informasi Kamar -->
            <div class="card">
                <h3>Kamar Saat Ini</h3>
                <?php if ($data_kamar) { ?>
                    <p style="font-size: 28px; font-weight: bold; margin: 5px 0;">No. <?= htmlspecialchars($data_kamar['nomor_kamar']); ?></p>
                    <p style="margin: 5px 0; font-size: 14px;">Tipe: <?= htmlspecialchars($data_kamar['tipe_kamar']); ?></p>
                    <p style="margin: 5px 0; font-size: 14px;">Sewa: Rp <?= number_format($data_kamar['harga'], 0, ',', '.'); ?> / bulan</p>
                    <p style="margin: 5px 0; font-size: 14px; color: #666;">Fasilitas: <?= htmlspecialchars($data_kamar['fasilitas']); ?></p>
                    <p style="margin: 12px 0 0 0;"><a href="inventaris.php" style="color: #111; font-weight: bold; font-size: 13px; text-decoration: underline;">Lihat Inventaris Kamar &rarr;</a></p>
                <?php } else { ?>
                    <p style="color: #666;">Belum terhubung ke kamar manapun.</p>
                <?php } ?>
            </div>

            <!-- Status Tagihan Terakhir -->
            <div class="card">
                <h3>Status Tagihan Aktif</h3>
                <?php if ($data_tagihan) { ?>
                    <p style="font-size: 22px; font-weight: bold; margin: 5px 0;">
                        Rp <?= number_format($data_tagihan['jumlah'], 0, ',', '.'); ?>
                    </p>
                    <p style="margin: 5px 0; font-size: 13px; color: #666;">
                        <?= strtoupper(str_replace('_', ' ', $data_tagihan['jenis'])); ?> - <?= htmlspecialchars($data_tagihan['bulan']); ?>
                    </p>
                    <?php if ($data_tagihan['jatuh_tempo']) { ?>
                        <p style="margin: 5px 0; font-size: 13px;">Jatuh tempo: <strong><?= htmlspecialchars($data_tagihan['jatuh_tempo']); ?></strong></p>
                    <?php } ?>
                    <p style="margin: 10px 0;">
                        <span class="badge"><?= strtoupper(str_replace('_', ' ', $data_tagihan['status_pembayaran'])); ?></span>
                    </p>
                    <a href="tagihan-saya.php" style="color: #111; font-weight: bold; font-size: 13px; text-decoration: underline;">Lihat Detail Tagihan &rarr;</a>
                <?php } else { ?>
                    <p style="color: #666;">Tidak ada tagihan aktif.</p>
                <?php } ?>
            </div>

            <!-- Rekap Pembayaran -->
            <div class="card">
                <h3>Rekap Pembayaran</h3>
                <p style="margin: 5px 0; font-size: 14px;">Total tagihan: <strong><?= (int)$data_rekap['jumlah_tagihan']; ?></strong></p>
                <p style="margin: 5px 0; font-size: 14px;">Sudah lunas: <strong><?= (int)$data_rekap['jumlah_lunas']; ?></strong></p>
                <p style="margin: 5px 0; font-size: 22px; font-weight: bold;">
                    Rp <?= number_format($data_rekap['total_tagihan'], 0, ',', '.'); ?>
                </p>
                <p style="margin: 0; font-size: 12px; color: #666;">Total outstanding</p>
            </div>
        </div>
    </div>

</body>
</html>