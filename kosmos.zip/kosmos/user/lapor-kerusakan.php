<?php
session_start();
include '../koneksi.php';

// Proteksi Halaman User
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit;
}

$user_id = (int)$_SESSION['user_id'];
$pesan = "";

// PROSES KIRIM LAPORAN / KOMPLAIN (kolom: user_id, judul_laporan, deskripsi, status_laporan)
if (isset($_POST['kirim_laporan'])) {
    $judul_laporan = trim($_POST['judul_laporan']);
    $deskripsi     = trim($_POST['deskripsi']);
    $validasi      = [];

    if (strlen($judul_laporan) < 3 || strlen($judul_laporan) > 150) $validasi[] = "Judul laporan harus 3-150 karakter.";
    if (strlen($deskripsi) < 10 || strlen($deskripsi) > 2000)       $validasi[] = "Deskripsi minimal 10 dan maksimal 2000 karakter.";

    if (!empty($validasi)) {
        $pesan = "<div class='alert'>" . htmlspecialchars(implode(" ", $validasi)) . "</div>";
    } else {
        $stmt = $conn->prepare("INSERT INTO komplain (user_id, judul_laporan, deskripsi, status_laporan) VALUES (?, ?, ?, 'pending')");
        $stmt->bind_param('iss', $user_id, $judul_laporan, $deskripsi);
        if ($stmt->execute()) {
            $pesan = "<div class='alert'>Laporan kerusakan berhasil dikirim ke pengelola kos!</div>";
        } else {
            $pesan = "<div class='alert'>Gagal mengirim laporan, silakan coba lagi.</div>";
        }
        $stmt->close();
    }
}

// Ambil riwayat komplain milik user ini dengan JOIN ke users dan kamar
$query_riwayat = null;
$stmt_riwayat = $conn->prepare(
    "SELECT komplain.*, kamar.nomor_kamar
     FROM komplain
     JOIN users ON komplain.user_id = users.id
     LEFT JOIN kamar ON users.id_kamar = kamar.id
     WHERE komplain.user_id = ?
     ORDER BY komplain.id DESC"
);
$stmt_riwayat->bind_param('i', $user_id);
$stmt_riwayat->execute();
$query_riwayat = $stmt_riwayat->get_result();

// Inventaris kamar penyewa ini sebagai acuan laporan kerusakan
$stmt_inventaris = $conn->prepare(
    "SELECT inventaris.* FROM inventaris
     JOIN users ON inventaris.kamar_id = users.id_kamar
     WHERE users.id = ? AND inventaris.lokasi = 'kamar'
     ORDER BY inventaris.nama_barang ASC"
);
$stmt_inventaris->bind_param('i', $user_id);
$stmt_inventaris->execute();
$query_inventaris = $stmt_inventaris->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lapor Kerusakan - Kosmos</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f0f0; color: #111111; margin: 0; padding: 0; }
        .sidebar { width: 250px; background: #111111; color: #ffffff; position: fixed; height: 100%; padding: 20px; box-sizing: border-box; }
        .sidebar h2 { font-size: 20px; letter-spacing: 1px; text-align: center; margin-bottom: 30px; border-bottom: 1px solid #444; padding-bottom: 15px; }
        .sidebar a { display: block; color: #ffffff; text-decoration: none; padding: 10px 15px; margin-bottom: 8px; border-radius: 4px; font-size: 14px; }
        .sidebar a:hover, .sidebar a.active { background: #333333; }
        .sidebar a.logout { background: #ffffff; color: #111111; font-weight: bold; text-align: center; margin-top: 40px; }
        .main-content { margin-left: 250px; padding: 40px; box-sizing: border-box; }
        .card-form, .card-table { background: #ffffff; padding: 25px; border: 2px solid #111111; border-radius: 6px; box-shadow: 4px 4px 0px #111111; margin-bottom: 30px; }
        h2 { margin-top: 0; }
        label { font-weight: 600; font-size: 13px; color: #333; }
        input[type="text"], textarea { width: 100%; padding: 10px; margin: 6px 0 15px 0; border: 1.5px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size: 14px; }
        input:focus, textarea:focus { border-color: #111; outline: none; }
        button[type="submit"] { background: #111111; color: #ffffff; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: bold; font-size: 14px; }
        button[type="submit"]:hover { background: #333333; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #111111; padding: 10px; text-align: left; font-size: 14px; vertical-align: middle; }
        th { background: #111111; color: #ffffff; }
        tr:nth-child(even) { background: #f9f9f9; }
        .alert { padding: 12px 15px; background: #111; color: #fff; margin-bottom: 15px; border-radius: 4px; font-size: 13px; }
        .badge { padding: 4px 8px; border-radius: 3px; font-size: 11px; font-weight: bold; text-transform: uppercase; white-space: nowrap; }
    </style>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

    <div class="sidebar">
        <h2>KOSMOS PENYEWA</h2>
        <a href="dashboard.php">Dashboard Saya</a>
        <a href="tagihan-saya.php">Tagihan Saya</a>
        <a href="inventaris.php">Inventaris Saya</a>
        <a href="lapor-kerusakan.php" class="active">Lapor Kerusakan</a>
        <a href="../logout.php" class="logout">LOGOUT</a>
    </div>

    <div class="main-content">
        <h1>Lapor Kerusakan / Kendala Fasilitas</h1>
        <p style="color: #666; margin-bottom: 25px;">Sampaikan kendala fasilitas kamar kos Anda kepada pengelola.</p>

        <?= $pesan; ?>

        <div class="card-form">
            <h2>Buat Laporan Baru</h2>
            <form action="" method="POST">
                <label>Judul Laporan / Kerusakan</label>
                <input type="text" name="judul_laporan" placeholder="Contoh: AC Bocor / Lampu Mati" minlength="3" maxlength="150" required>

                <label>Detail Deskripsi Kendala</label>
                <textarea name="deskripsi" rows="4" placeholder="Jelaskan detail kendala fasilitas kamar kos Anda..." minlength="10" maxlength="2000" required></textarea>
                
                <button type="submit" name="kirim_laporan">KIRIM LAPORAN</button>
            </form>

            <?php if ($query_inventaris && $query_inventaris->num_rows > 0) { ?>
            <p style="font-size: 12px; color: #666; margin: 18px 0 0 0;">
                Fasilitas kamar Anda:
                <?php 
                $nama_barang = [];
                $query_inventaris->data_seek(0);
                while ($inv = $query_inventaris->fetch_assoc()) $nama_barang[] = $inv['nama_barang'] . ' (' . str_replace('_', ' ', $inv['kondisi']) . ')';
                echo htmlspecialchars(implode(', ', $nama_barang));
                ?>
            </p>
            <?php } ?>
        </div>

        <div class="card-table">
            <h2>Riwayat Laporan Anda</h2>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Judul & Kendala</th>
                        <th>Waktu Lapor</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    if ($query_riwayat && mysqli_num_rows($query_riwayat) > 0) {
                        while ($row = mysqli_fetch_assoc($query_riwayat)) { 
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td>
                            <strong><?= htmlspecialchars($row['judul_laporan']); ?></strong><br>
                            <span style="font-size: 13px; color: #555;"><?= htmlspecialchars($row['deskripsi']); ?></span>
                        </td>
                        <td><?= htmlspecialchars($row['tanggal_laporan']); ?></td>
                        <td>
                            <?php $badge = ['selesai' => '#28a745; color:#fff;', 'diproses' => '#f0ad4e; color:#fff;', 'pending' => '#111; color:#fff;']; ?>
                            <span class="badge" style="background:<?= $badge[$row['status_laporan']] ?? '#111; color:#fff;' ?>">
                                <?= strtoupper(str_replace('_', ' ', $row['status_laporan'])); ?>
                            </span>
                        </td>
                    </tr>
                    <?php 
                        }
                    } else { 
                    ?>
                    <tr>
                        <td colspan="4" style="text-align: center; color: #666; padding: 20px;">Belum ada laporan kerusakan yang dikirim.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>