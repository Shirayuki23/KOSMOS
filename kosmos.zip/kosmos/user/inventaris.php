<?php
session_start();
include '../koneksi.php';

// Proteksi Halaman User
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit;
}

$user_id = (int)$_SESSION['user_id'];

// Data kamar + identitas penghuni yang sedang login
$stmt_user = $conn->prepare(
    "SELECT u.nama, u.id_kamar, k.nomor_kamar, k.tipe_kamar
     FROM users u LEFT JOIN kamar k ON u.id_kamar = k.id
     WHERE u.id = ?"
);
$stmt_user->bind_param('i', $user_id);
$stmt_user->execute();
$data_user = $stmt_user->get_result()->fetch_assoc();
$stmt_user->close();

$id_kamar = !empty($data_user['id_kamar']) ? (int)$data_user['id_kamar'] : null;

// Inventaris kamar sendiri + area bersama (sifatnya hanya dibaca oleh penghuni)
$query_kamar_items = null;
if ($id_kamar !== null) {
    $stmt = $conn->prepare("SELECT * FROM inventaris WHERE lokasi = 'kamar' AND kamar_id = ? ORDER BY nama_barang ASC");
    $stmt->bind_param('i', $id_kamar);
    $stmt->execute();
    $query_kamar_items = $stmt->get_result();
    $stmt->close();
}

$query_bersama = $conn->query("SELECT * FROM inventaris WHERE lokasi = 'area_bersama' ORDER BY nama_barang ASC");

$kondisi_bg = ['baik' => '#111; color:#fff;', 'perlu_perbaikan' => '#eee; color:#333; border:1px solid #111;', 'rusak' => '#ccc; color:#333;'];
$kondisi_default = '#fff; color:#111; border:1px solid #111;';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventaris - Kosmos</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f0f0; color: #111111; margin: 0; padding: 0; }
        .sidebar { width: 250px; background: #111111; color: #ffffff; position: fixed; height: 100%; padding: 20px; box-sizing: border-box; }
        .sidebar h2 { font-size: 20px; letter-spacing: 1px; text-align: center; margin-bottom: 30px; border-bottom: 1px solid #444; padding-bottom: 15px; }
        .sidebar a { display: block; color: #ffffff; text-decoration: none; padding: 10px 15px; margin-bottom: 8px; border-radius: 4px; font-size: 14px; }
        .sidebar a:hover, .sidebar a.active { background: #333333; }
        .sidebar a.logout { background: #ffffff; color: #111111; font-weight: bold; text-align: center; margin-top: 40px; }
        .main-content { margin-left: 250px; padding: 40px; box-sizing: border-box; }
        .card-table { background: #ffffff; padding: 25px; border: 2px solid #111111; border-radius: 6px; box-shadow: 4px 4px 0px #111111; margin-bottom: 30px; }
        h2 { margin-top: 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #111111; padding: 10px; text-align: left; font-size: 14px; vertical-align: middle; }
        th { background: #111111; color: #ffffff; }
        .badge { padding: 4px 8px; border-radius: 3px; font-size: 11px; font-weight: bold; text-transform: uppercase; }
    </style>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

    <div class="sidebar">
        <h2>KOSMOS PENYEWA</h2>
        <a href="dashboard.php">Dashboard Saya</a>
        <a href="tagihan-saya.php">Tagihan Saya</a>
        <a href="inventaris.php" class="active">Inventaris Saya</a>
        <a href="lapor-kerusakan.php">Lapor Kerusakan</a>
        <a href="../logout.php" class="logout">LOGOUT</a>
    </div>

    <div class="main-content">
        <h1>Inventaris Fasilitas</h1>
        <p style="color: #666; margin-bottom: 25px;">
            <?php if ($id_kamar !== null) { ?>
                Daftar barang di Kamar No. <?= htmlspecialchars($data_user['nomor_kamar']); ?> dan fasilitas area bersama.
                Ada kerusakan? <a href="lapor-kerusakan.php" style="color:#111; font-weight:bold;">Lapor Kerusakan</a>.
            <?php } else { ?>
                Anda belum ditempatkan ke kamar manapun, sehingga inventaris kamar belum tersedia.
            <?php } ?>
        </p>

        <div class="card-table">
            <h2>Fasilitas Kamar Saya</h2>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Kondisi</th>
                        <th>Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    if ($query_kamar_items && $query_kamar_items->num_rows > 0) {
                        while ($row = $query_kamar_items->fetch_assoc()) { 
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><strong><?= htmlspecialchars($row['nama_barang']); ?></strong></td>
                        <td>
                            <span class="badge" style="background:<?= $kondisi_bg[$row['kondisi']] ?? $kondisi_default ?>"><?= strtoupper(str_replace('_', ' ', $row['kondisi'])); ?></span>
                        </td>
                        <td><?= (int)$row['jumlah']; ?></td>
                    </tr>
                    <?php 
                        }
                    } else { 
                    ?>
                    <tr>
                        <td colspan="4" class="empty-state">
                            <?= $id_kamar === null ? 'Belum ada kamar aktif untuk Anda.' : 'Belum ada barang inventaris tercatat untuk kamar ini.' ?>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <div class="card-table">
            <h2>Fasilitas Area Bersama</h2>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Kondisi</th>
                        <th>Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    if ($query_bersama && $query_bersama->num_rows > 0) {
                        while ($row = $query_bersama->fetch_assoc()) { 
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><strong><?= htmlspecialchars($row['nama_barang']); ?></strong></td>
                        <td>
                            <span class="badge" style="background:<?= $kondisi_bg[$row['kondisi']] ?? $kondisi_default ?>"><?= strtoupper(str_replace('_', ' ', $row['kondisi'])); ?></span>
                        </td>
                        <td><?= (int)$row['jumlah']; ?></td>
                    </tr>
                    <?php 
                        }
                    } else { 
                    ?>
                    <tr>
                        <td colspan="4" class="empty-state">Belum ada fasilitas area bersama tercatat.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>
