-- Migrasi 003 - Menyelaraskan status kamar dengan penghuni sebenarnya
-- Kamar dengan penghuni aktif menjadi 'terisi', kamar 'terisi' yang tidak punya
-- penghuni dikembalikan menjadi 'tersedia'. Status 'maintenance' tidak diubah.
-- Aman dijalankan berulang (idempotent).

USE db_kosmos;

UPDATE kamar k
LEFT JOIN users u ON u.id_kamar = k.id AND u.status_akun != 'ditolak'
SET k.status = CASE
    WHEN u.id IS NOT NULL THEN 'terisi'
    WHEN k.status = 'terisi' THEN 'tersedia'
    ELSE k.status
END;
