-- Migrasi 002 - Mencegah penghapusan kamar yang masih ditempati penyewa
-- Mengubah fk_users_kamar dari ON DELETE SET NULL menjadi ON DELETE RESTRICT
-- agar penghuni harus dipindahkan/ditolak lebih dulu sebelum kamar dihapus.
-- Jalankan setelah 001_penyesuaian_skema_laporan.sql.

USE db_kosmos;

ALTER TABLE users DROP FOREIGN KEY fk_users_kamar;

ALTER TABLE users
  ADD CONSTRAINT fk_users_kamar FOREIGN KEY (id_kamar) REFERENCES kamar (id) ON DELETE RESTRICT;
