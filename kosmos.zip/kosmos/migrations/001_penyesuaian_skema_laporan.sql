-- Migrasi 001 - Penyelarasan skema db_kosmos dengan kebutuhan fungsional laporan
-- Menambah state 'ditolak', kolom tagihan DP/sewa bulanan + jatuh tempo,
-- tabel inventaris, relasi FK penghuni-kamar, dan data 8 kamar 4K Kost.
-- Jalankan satu kali; bagian INSERT tidak idempotent.

USE db_kosmos;

-- 1. Status akun dan status pembayaran yang dipakai modul verifikasi/konfirmasi
ALTER TABLE users
  MODIFY status_akun ENUM('pending','aktif','ditolak') NOT NULL DEFAULT 'pending';

ALTER TABLE tagihan
  MODIFY status_pembayaran ENUM('belum_bayar','menunggu_konfirmasi','lunas','ditolak') NOT NULL DEFAULT 'belum_bayar';

-- 2. Tagihan: jenis (DP / sewa bulanan) dan jatuh tempo
ALTER TABLE tagihan
  ADD COLUMN jenis ENUM('dp','sewa_bulanan') NOT NULL DEFAULT 'sewa_bulanan' AFTER kamar_id,
  ADD COLUMN jatuh_tempo DATE NULL AFTER jumlah;

ALTER TABLE tagihan
  MODIFY bulan VARCHAR(50) NOT NULL;

UPDATE tagihan SET jenis = 'dp' WHERE bulan = 'DP / Bulan Pertama';

-- 3. Relasi kamar 1:N penghuni
ALTER TABLE users
  ADD CONSTRAINT fk_users_kamar FOREIGN KEY (id_kamar) REFERENCES kamar (id) ON DELETE SET NULL;

-- 4. Inventaris fasilitas kamar dan area bersama (FR-12)
CREATE TABLE inventaris (
  id INT(11) NOT NULL AUTO_INCREMENT,
  nama_barang VARCHAR(100) NOT NULL,
  lokasi ENUM('kamar','area_bersama') NOT NULL DEFAULT 'kamar',
  kamar_id INT(11) DEFAULT NULL,
  kondisi ENUM('baik','perlu_perbaikan','rusak') NOT NULL DEFAULT 'baik',
  jumlah INT(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  KEY kamar_id (kamar_id),
  CONSTRAINT fk_inventaris_kamar FOREIGN KEY (kamar_id) REFERENCES kamar (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Data kamar 4K Kost (8 kamar) dan inventaris awal
INSERT INTO kamar (nomor_kamar, tipe_kamar, harga, fasilitas, status, foto) VALUES
('03', 'Large',  1400000.00, 'Kasur, Lemari, Meja Belajar, Kamar Mandi Dalam, AC', 'tersedia', ''),
('04', 'Large',  1400000.00, 'Kasur, Lemari, Meja Belajar, Kamar Mandi Dalam, AC', 'terisi', ''),
('05', 'Standar', 1100000.00, 'Kasur, Lemari, Meja Belajar, Kamar Mandi Luar', 'tersedia', ''),
('06', 'Standar', 1100000.00, 'Kasur, Lemari, Meja Belajar, Kamar Mandi Luar', 'maintenance', ''),
('07', 'Deluxe',  1700000.00, 'Kasur, Lemari, Meja Belajar, Kamar Mandi Dalam, AC, Water Heater', 'tersedia', ''),
('08', 'Deluxe',  1700000.00, 'Kasur, Lemari, Meja Belajar, Kamar Mandi Dalam, AC, Water Heater', 'terisi', '');

INSERT INTO inventaris (nama_barang, lokasi, kamar_id, kondisi, jumlah) VALUES
('Kasur', 'kamar', 2, 'baik', 1),
('Lemari Pakaian', 'kamar', 2, 'baik', 1),
('AC Split 1/2 PK', 'kamar', 2, 'perlu_perbaikan', 1),
('Meja Belajar', 'kamar', 3, 'baik', 1),
('Kompor Gas', 'area_bersama', NULL, 'baik', 2),
('Wastafel Cuci Piring', 'area_bersama', NULL, 'baik', 1),
('Mesin Cuci', 'area_bersama', NULL, 'perlu_perbaikan', 1),
('Tabung APAR', 'area_bersama', NULL, 'baik', 1);
