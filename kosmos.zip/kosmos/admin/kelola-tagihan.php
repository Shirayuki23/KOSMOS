<?php
session_start();
include '../koneksi.php';

// Proteksi Halaman Admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$pesan = "";

function alert_admin($teks) {
    return "<div class='alert'>" . htmlspecialchars($teks) . "</div>";
}

$jenis_terima = ['dp', 'sewa_bulanan'];

// 1. TERBITKAN TAGIHAN BARU (FR-09)
if (isset($_POST['terbit_tagihan'])) {
    $user_id     = (int)$_POST['user_id'];
    $jenis       = $_POST['jenis'];
    $periode     = trim($_POST['periode']);
    $jumlah      = str_replace(['.', ','], ['', '.'], $_POST['jumlah']);
    $jatuh_tempo = trim($_POST['jatuh_tempo']);
    $validasi    = [];

    if (!in_array($jenis, $jenis_terima, true)) $validasi[] = "Jenis tagihan tidak valid.";
    if ($periode === '' || strlen($periode) > 50) $validasi[] = "Periode wajib diisi maksimal 50 karakter.";
    if (!is_numeric($jumlah) || (float)$jumlah <= 0) $validasi[] = "Jumlah tagihan harus lebih dari nol.";
    if ($jatuh_tempo !== '' && !DateTime::createFromFormat('Y-m-d', $jatuh_tempo)) $validasi[] = "Format jatuh tempo tidak valid.";

    $stmt = $conn->prepare(
        "SELECT u.id, u.nama, u.id_kamar, k.nomor_kamar, k.harga
         FROM users u LEFT JOIN kamar k ON u.id_kamar = k.id
         WHERE u.id = ? AND u.role != 'admin' AND u.status_akun = 'aktif'"
    );
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $d_penyewa = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$d_penyewa) {
        $validasi[] = "Penyewa harus berstatus aktif.";
    } elseif (empty($d_penyewa['id_kamar'])) {
        $validasi[] = "Penyewa belum ditempatkan ke kamar manapun.";
    } else {
        $cek = $conn->prepare("SELECT id FROM tagihan WHERE user_id = ? AND jenis = ? AND bulan = ?");
        $cek->bind_param('iss', $user_id, $jenis, $periode);
        $cek->execute();
        if ($cek->get_result()->fetch_assoc()) $validasi[] = "Tagihan " . strtoupper(str_replace('_', ' ', $jenis)) . " periode " . $periode . " sudah terbit.";
        $cek->close();
    }

    if (!empty($validasi)) {
        $pesan = alert_admin(implode(" ", $validasi));
    } else {
        $kamar_id = (int)$d_penyewa['id_kamar'];
        $jumlah   = (float)$jumlah;
        $tempo    = $jatuh_tempo === '' ? null : $jatuh_tempo;

        $stmt = $conn->prepare(
            "INSERT INTO tagihan (user_id, kamar_id, jenis, bulan, jumlah, jatuh_tempo, status_pembayaran)
             VALUES (?, ?, ?, ?, ?, ?, 'belum_bayar')"
        );
        $stmt->bind_param('iissds', $user_id, $kamar_id, $jenis, $periode, $jumlah, $tempo);
        if ($stmt->execute()) {
            $pesan = alert_admin("Tagihan " . strtoupper(str_replace('_', ' ', $jenis)) . " untuk " . $d_penyewa['nama'] . " berhasil diterbitkan.");
        } else {
            $pesan = alert_admin("Gagal menerbitkan tagihan: " . $conn->error);
        }
        $stmt->close();
    }
}

// 2. PERBAIKAN TAGIHAN BELUM BAYAR
if (isset($_POST['update_tagihan'])) {
    $id_tagihan  = (int)$_POST['id_tagihan'];
    $periode     = trim($_POST['periode']);
    $jumlah      = str_replace(['.', ','], ['', '.'], $_POST['jumlah']);
    $jatuh_tempo = trim($_POST['jatuh_tempo']) === '' ? null : trim($_POST['jatuh_tempo']);
    $validasi    = [];

    if ($periode === '' || strlen($periode) > 50) $validasi[] = "Periode wajib diisi maksimal 50 karakter.";
    if (!is_numeric($jumlah) || (float)$jumlah <= 0) $validasi[] = "Jumlah tagihan harus lebih dari nol.";

    if (!empty($validasi)) {
        $pesan = alert_admin(implode(" ", $validasi));
    } else {
        $jumlah = (float)$jumlah;
        $stmt = $conn->prepare(
            "UPDATE tagihan SET bulan = ?, jumlah = ?, jatuh_tempo = ?
             WHERE id = ? AND status_pembayaran IN ('belum_bayar', 'ditolak')"
        );
        $stmt->bind_param('sdsi', $periode, $jumlah, $jatuh_tempo, $id_tagihan);
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $pesan = alert_admin("Tagihan berhasil diperbarui.");
        } else {
            $pesan = alert_admin("Tagihan tidak ditemukan atau sudah tidak dapat diubah.");
        }
        $stmt->close();
    }
}

// 3. HAPUS TAGIHAN
if (isset($_GET['hapus']) && ctype_digit((string)$_GET['hapus'])) {
    $id_tagihan = (int)$_GET['hapus'];
    $stmt = $conn->prepare("SELECT * FROM tagihan WHERE id = ?");
    $stmt->bind_param('i', $id_tagihan);
    $stmt->execute();
    $d_tagihan = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($d_tagihan && $d_tagihan['status_pembayaran'] === 'lunas') {
        $pesan = alert_admin("Tagihan yang sudah lunas tidak boleh dihapus.");
    } elseif ($d_tagihan) {
        $stmt = $conn->prepare("DELETE FROM tagihan WHERE id = ?");
        $stmt->bind_param('i', $id_tagihan);
        $stmt->execute();
        $stmt->close();
        if (!empty($d_tagihan['bukti_bayar']) && is_file('../uploads/pembayaran/' . $d_tagihan['bukti_bayar'])) {
            unlink('../uploads/pembayaran/' . $d_tagihan['bukti_bayar']);
        }
        $pesan = alert_admin("Tagihan berhasil dihapus.");
    }
}

// Data untuk form: penyewa aktif berkamar + daftar tagihan
$penyewa_list = [];
$q_penyewa = $conn->query(
    "SELECT u.id, u.nama, u.id_kamar, k.nomor_kamar, k.harga
     FROM users u JOIN kamar k ON u.id_kamar = k.id
     WHERE u.role != 'admin' AND u.status_akun = 'aktif'
     ORDER BY k.nomor_kamar ASC"
);
while ($p = $q_penyewa->fetch_assoc()) $penyewa_list[] = $p;

$query_tagihan = $conn->query(
    "SELECT t.*, u.nama, u.email, k.nomor_kamar
     FROM tagihan t
     JOIN users u ON t.user_id = u.id
     JOIN kamar k ON t.kamar_id = k.id
     ORDER BY t.id DESC"
);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Tagihan - Kosmos Admin</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f0f0; color: #111111; margin: 0; padding: 0; }
        .sidebar { width: 250px; background: #111111; color: #ffffff; position: fixed; height: 100%; padding: 20px; box-sizing: border-box; }
        .sidebar h2 { font-size: 20px; letter-spacing: 1px; text-align: center; margin-bottom: 30px; border-bottom: 1px solid #444; padding-bottom: 15px; }
        .sidebar a { display: block; color: #ffffff; text-decoration: none; padding: 10px 15px; margin-bottom: 8px; border-radius: 4px; font-size: 14px; }
        .sidebar a:hover, .sidebar a.active { background: #333333; }
        .sidebar a.logout { background: #ffffff; color: #111111; font-weight: bold; text-align: center; margin-top: 40px; }
        .main-content { margin-left: 250px; padding: 40px; box-sizing: border-box; }
        .card-form, .card-table { background: #ffffff; padding: 25px; border: 2px solid #111111; border-radius: 6px; box-shadow: 4px 4px 0px #111111; margin-bottom: 30px; }
        h2 { margin-top: 0; }
        label { font-weight: 600; font-size: 13px; color: #333; }
        input[type="text"], input[type="number"], input[type="date"], select { width: 100%; padding: 10px; margin: 6px 0 15px 0; border: 1.5px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size: 14px; }
        input:focus, select:focus { border-color: #111; outline: none; }
        button[type="submit"] { background: #111111; color: #ffffff; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: bold; font-size: 14px; }
        button[type="submit"]:hover { background: #333333; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #111111; padding: 10px; text-align: left; font-size: 14px; vertical-align: middle; }
        th { background: #111111; color: #ffffff; }
        .badge { padding: 4px 8px; border-radius: 3px; font-size: 11px; font-weight: bold; text-transform: uppercase; }
        .alert { padding: 12px 15px; background: #111; color: #fff; margin-bottom: 15px; border-radius: 4px; font-size: 13px; }
        .btn-hapus { background: #fff; color: #111; border: 1.5px solid #111; padding: 5px 11px; text-decoration: none; border-radius: 3px; font-size: 12px; font-weight: bold; display: inline-block; }
        .btn-hapus:hover { background: #111; color: #fff; }
        .form-inline-edit { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
        .form-inline-edit input { width: auto; margin: 0; padding: 6px; font-size: 12px; }
        .form-inline-edit button { padding: 6px 12px; font-size: 12px; margin: 0; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 0 20px; }
    </style>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

    <div class="sidebar">
        <h2>KOSMOS ADMIN</h2>
        <a href="dashboard.php">Dashboard Utama</a>
        <a href="kelola-kamar.php">Kelola Kamar</a>
        <a href="verifikasi-penyewa.php">Verifikasi Penyewa</a>
        <a href="konfirmasi-pembayaran.php">Konfirmasi Pembayaran</a>
        <a href="kelola-tagihan.php" class="active">Kelola Tagihan</a>
        <a href="kelola-inventaris.php">Kelola Inventaris</a>
        <a href="kelola-laporan.php">Kelola Laporan</a>
        <a href="../logout.php" class="logout">LOGOUT</a>
    </div>

    <div class="main-content">
        <h1>Kelola Tagihan</h1>
        <p style="color: #666; margin-bottom: 25px;">Terbitkan tagihan DP dan sewa bulanan, perbaiki nominal atau jatuh tempo, serta hapus tagihan yang keliru catat.</p>

        <?= $pesan; ?>

        <div class="card-form">
            <h2>Terbitkan Tagihan Baru</h2>
            <?php if (empty($penyewa_list)) { ?>
                <p style="color: #666;">Belum ada penyewa aktif yang menempati kamar. Verifikasi penyewa dan tetapkan kamar terlebih dahulu.</p>
            <?php } else { ?>
            <form action="" method="POST">
                <label>Penyewa & Kamar</label>
                <select name="user_id" required>
                    <?php foreach ($penyewa_list as $p) { ?>
                        <option value="<?= (int)$p['id']; ?>" data-harga="<?= (float)$p['harga']; ?>">
                            Kamar <?= htmlspecialchars($p['nomor_kamar']); ?> - <?= htmlspecialchars($p['nama']); ?>
                        </option>
                    <?php } ?>
                </select>

                <div class="grid-2">
                    <div>
                        <label>Jenis Tagihan</label>
                        <select name="jenis" id="select_jenis">
                            <option value="dp">DP / Uang Muka</option>
                            <option value="sewa_bulanan">Sewa Bulanan</option>
                        </select>
                    </div>
                    <div>
                        <label>Periode</label>
                        <input type="text" name="periode" id="input_periode" placeholder="Contoh: Desember 2026" maxlength="50" required>
                    </div>
                </div>

                <div class="grid-2">
                    <div>
                        <label>Jumlah (Rupiah)</label>
                        <input type="number" name="jumlah" id="input_jumlah" min="1" step="1" required>
                    </div>
                    <div>
                        <label>Jatuh Tempo</label>
                        <input type="date" name="jatuh_tempo">
                    </div>
                </div>

                <button type="submit" name="terbit_tagihan">TERBITKAN TAGIHAN</button>
            </form>
            <?php } ?>
        </div>

        <div class="card-table">
            <h2>Daftar Tagihan</h2>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Penyewa & Kamar</th>
                        <th>Jenis</th>
                        <th>Periode</th>
                        <th>Jumlah</th>
                        <th>Jatuh Tempo</th>
                        <th>Status Bayar</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    if ($query_tagihan && $query_tagihan->num_rows > 0) {
                        while ($row = $query_tagihan->fetch_assoc()) { 
                            $boleh_ubah = in_array($row['status_pembayaran'], ['belum_bayar', 'ditolak'], true);
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td>
                            <strong><?= htmlspecialchars($row['nama']); ?></strong><br>
                            <span style="font-size: 12px; color: #666;">Kamar <?= htmlspecialchars($row['nomor_kamar']); ?></span>
                        </td>
                        <td><span class="badge" style="background:#eee;color:#333;border:1px solid #111;"><?= strtoupper(str_replace('_', ' ', $row['jenis'])); ?></span></td>
                        <td><?= htmlspecialchars($row['bulan']); ?></td>
                        <td><strong>Rp <?= number_format($row['jumlah'], 0, ',', '.'); ?></strong></td>
                        <td><?= $row['jatuh_tempo'] ? htmlspecialchars($row['jatuh_tempo']) : '<span style="color:#666;">-</span>' ?></td>
                        <td>
                            <?php $warna = ['lunas' => '#111; color:#fff;', 'menunggu_konfirmasi' => '#eee; color:#333; border:1px solid #111;', 'ditolak' => '#ccc; color:#333;']; $style = $warna[$row['status_pembayaran']] ?? '#fff; color:#111; border:1px solid #111;'; ?>
                            <span class="badge" style="background:<?= $style ?>"><?= strtoupper(str_replace('_', ' ', $row['status_pembayaran'])); ?></span>
                        </td>
                        <td>
                            <?php if ($boleh_ubah) { ?>
                            <form action="" method="POST" class="form-inline-edit">
                                <input type="hidden" name="id_tagihan" value="<?= (int)$row['id']; ?>">
                                <input type="text" name="periode" value="<?= htmlspecialchars($row['bulan']); ?>" size="14" required>
                                <input type="number" name="jumlah" value="<?= (int)$row['jumlah']; ?>" min="1" step="1" size="10" required>
                                <input type="date" name="jatuh_tempo" value="<?= htmlspecialchars($row['jatuh_tempo'] ?? ''); ?>">
                                <button type="submit" name="update_tagihan">SIMPAN</button>
                                <a href="kelola-tagihan.php?hapus=<?= (int)$row['id']; ?>" class="btn-hapus" onclick="return confirm('Hapus tagihan ini?')">Hapus</a>
                            </form>
                            <?php } else { ?>
                                <span style="font-size: 12px; color: #666; font-weight: bold;">
                                    <?= $row['status_pembayaran'] === 'lunas' ? 'Sudah Lunas' : 'Menunggu Konfirmasi' ?>
                                </span>
                            <?php } ?>
                        </td>
                    </tr>
                    <?php 
                        }
                    } else { 
                    ?>
                    <tr>
                        <td colspan="8" class="empty-state">Belum ada tagihan tercatat.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Nominal sewa bulanan mengikuti harga kamar terpilih; DP diisi manual oleh admin.
        var selectPenyewa = document.querySelector('select[name="user_id"]');
        var inputJumlah = document.getElementById('input_jumlah');
        var selectJenis = document.getElementById('select_jenis');
        var inputPeriode = document.getElementById('input_periode');

        function isiNominal() {
            if (!selectPenyewa || !inputJumlah) return;
            var opsi = selectPenyewa.options[selectPenyewa.selectedIndex];
            var harga = opsi ? parseFloat(opsi.dataset.harga) : 0;
            if (selectJenis.value === 'sewa_bulanan' && harga > 0) inputJumlah.value = harga;
        }

        function isiPeriode() {
            if (!inputPeriode) return;
            var bulan = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
            var d = new Date();
            inputPeriode.placeholder = selectJenis.value === 'dp'
                ? 'Contoh: DP / Bulan Pertama'
                : 'Contoh: ' + bulan[d.getMonth()] + ' ' + d.getFullYear();
        }

        if (selectPenyewa && selectJenis) {
            selectPenyewa.addEventListener('change', isiNominal);
            selectJenis.addEventListener('change', function () { isiNominal(); isiPeriode(); });
            isiNominal();
            isiPeriode();
        }
    </script>

</body>
</html>
