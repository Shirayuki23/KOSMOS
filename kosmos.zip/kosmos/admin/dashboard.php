<?php
session_start();
include '../koneksi.php';

// Proteksi Halaman: Cek apakah sudah login dan rolenya adalah admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Ambil data statistik ringkas dari database
$q_user  = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users WHERE role='user'");
$d_user  = mysqli_fetch_assoc($q_user);

$q_pending = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users WHERE role='user' AND status_akun='pending'");
$d_pending = mysqli_fetch_assoc($q_pending);

$q_kamar = mysqli_query($conn, "SELECT COUNT(*) AS total FROM kamar WHERE status='tersedia'");
$d_kamar = mysqli_fetch_assoc($q_kamar);

$q_tagihan = mysqli_query($conn, "SELECT COUNT(*) AS total FROM tagihan WHERE status_pembayaran='menunggu_konfirmasi'");
$d_tagihan = mysqli_fetch_assoc($q_tagihan);

$q_laporan = mysqli_query($conn, "SELECT COUNT(*) AS total FROM komplain WHERE status_laporan IN ('pending','diproses')");
$d_laporan = mysqli_fetch_assoc($q_laporan);

$q_masuk = mysqli_query($conn, "SELECT COALESCE(SUM(jumlah), 0) AS total FROM tagihan WHERE status_pembayaran='lunas'");
$d_masuk = mysqli_fetch_assoc($q_masuk);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Kosmos</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f0f0;
            color: #111111;
            margin: 0;
            padding: 0;
        }
        .sidebar {
            width: 250px;
            background: #111111;
            color: #ffffff;
            position: fixed;
            height: 100%;
            padding: 20px;
            box-sizing: border-box;
        }
        .sidebar h2 {
            font-size: 20px;
            letter-spacing: 1px;
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 1px solid #444;
            padding-bottom: 15px;
        }
        .sidebar a {
            display: block;
            color: #ffffff;
            text-decoration: none;
            padding: 10px 15px;
            margin-bottom: 8px;
            border-radius: 4px;
            font-size: 14px;
            transition: background 0.2s;
        }
        .sidebar a:hover {
            background: #333333;
        }
        .sidebar a.logout {
            background: #ffffff;
            color: #111111;
            font-weight: bold;
            text-align: center;
            margin-top: 40px;
        }
        .sidebar a.logout:hover {
            background: #cccccc;
        }
        .main-content {
            margin-left: 250px;
            padding: 40px;
            box-sizing: border-box;
        }
        .header-top {
            background: #ffffff;
            padding: 20px 30px;
            border: 2px solid #111111;
            border-radius: 6px;
            margin-bottom: 30px;
            box-shadow: 4px 4px 0px #111111;
        }
        .cards-container {
            display: flex;
            gap: 20px;
            margin-top: 20px;
        }
        .card {
            flex: 1;
            background: #ffffff;
            padding: 25px;
            border: 2px solid #111111;
            border-radius: 6px;
            box-shadow: 4px 4px 0px #111111;
        }
        .card h3 {
            margin: 0 0 10px 0;
            font-size: 14px;
            color: #666;
            text-transform: uppercase;
        }
        .card .number {
            font-size: 32px;
            font-weight: bold;
            color: #111111;
            margin: 0;
        }
        .card a { text-decoration: underline; }
    </style>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

    <!-- Sidebar Navigasi Admin -->
    <div class="sidebar">
        <h2>KOSMOS ADMIN</h2>
        <a href="dashboard.php">Dashboard Utama</a>
        <a href="kelola-kamar.php">Kelola Kamar</a>
        <a href="verifikasi-penyewa.php">Verifikasi Penyewa</a>
        <a href="konfirmasi-pembayaran.php">Konfirmasi Pembayaran</a>
        <a href="kelola-tagihan.php">Kelola Tagihan</a>
        <a href="kelola-inventaris.php">Kelola Inventaris</a>
        <a href="kelola-laporan.php">Kelola Laporan</a>
        <a href="../logout.php" class="logout">LOGOUT</a>
    </div>

    <!-- Konten Utama Dashboard -->
    <div class="main-content">
        <div class="header-top">
            <h1 style="margin: 0; font-size: 24px;">Selamat Datang, <?= htmlspecialchars($_SESSION['nama']); ?>!</h1>
            <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">Panel kendali utama pengelolaan data kos-kosan Kosmos.</p>
        </div>

        <h2>Statistik Sistem</h2>
        <div class="cards-container">
            <div class="card">
                <h3>Total Penyewa / User</h3>
                <p class="number"><?= $d_user['total']; ?></p>
            </div>
            <div class="card">
                <h3>Menunggu Verifikasi</h3>
                <p class="number"><?= $d_pending['total']; ?></p>
                <a href="verifikasi-penyewa.php" style="color:#111; font-size:12px; font-weight:bold;">Tinjau &rarr;</a>
            </div>
            <div class="card">
                <h3>Kamar Tersedia</h3>
                <p class="number"><?= $d_kamar['total']; ?></p>
                <a href="kelola-kamar.php" style="color:#111; font-size:12px; font-weight:bold;">Kelola kamar &rarr;</a>
            </div>
            <div class="card">
                <h3>Konfirmasi Pembayaran</h3>
                <p class="number"><?= $d_tagihan['total']; ?></p>
                <a href="konfirmasi-pembayaran.php" style="color:#111; font-size:12px; font-weight:bold;">Tinjau bayar &rarr;</a>
            </div>
            <div class="card">
                <h3>Laporan Aktif</h3>
                <p class="number"><?= $d_laporan['total']; ?></p>
                <a href="kelola-laporan.php" style="color:#111; font-size:12px; font-weight:bold;">Kelola laporan &rarr;</a>
            </div>
            <div class="card">
                <h3>Pemasukan Lunas</h3>
                <p class="number" style="font-size:22px;">Rp <?= number_format($d_masuk['total'], 0, ',', '.'); ?></p>
                <a href="kelola-tagihan.php" style="color:#111; font-size:12px; font-weight:bold;">Kelola tagihan &rarr;</a>
            </div>
        </div>
    </div>

</body>
</html>