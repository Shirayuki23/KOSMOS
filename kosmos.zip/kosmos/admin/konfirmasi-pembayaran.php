<?php
session_start();
include '../koneksi.php';

// Proteksi Halaman Admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$pesan = "";

function alert_admin($teks) {
    return "<div class='alert'>" . htmlspecialchars($teks) . "</div>";
}

// PROSES AKSI: TERIMA, TOLAK, ATAU RESET TAGIHAN
if (isset($_GET['aksi']) && isset($_GET['id']) && ctype_digit((string)$_GET['id'])) {
    $id_tagihan = (int)$_GET['id'];
    $aksi = $_GET['aksi'];

    $stmt = $conn->prepare("SELECT * FROM tagihan WHERE id = ?");
    $stmt->bind_param('i', $id_tagihan);
    $stmt->execute();
    $d_tagihan = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$d_tagihan) {
        $pesan = alert_admin("Tagihan tidak ditemukan.");
    } elseif ($aksi == 'terima') {
        if ($d_tagihan['status_pembayaran'] === 'lunas') {
            $pesan = alert_admin("Tagihan ini sudah berstatus lunas.");
        } elseif (empty($d_tagihan['bukti_bayar'])) {
            $pesan = alert_admin("Bukti pembayaran belum diunggah penyewa, konfirmasi ditolak.");
        } else {
            $stmt = $conn->prepare("UPDATE tagihan SET status_pembayaran = 'lunas', tanggal_bayar = NOW() WHERE id = ?");
            $stmt->bind_param('i', $id_tagihan);
            $stmt->execute();
            $stmt->close();
            $pesan = alert_admin("Pembayaran dikonfirmasi (LUNAS).");
        }
    } elseif ($aksi == 'tolak') {
        $stmt = $conn->prepare("UPDATE tagihan SET status_pembayaran = 'ditolak' WHERE id = ?");
        $stmt->bind_param('i', $id_tagihan);
        $stmt->execute();
        $stmt->close();
        $pesan = alert_admin("Bukti pembayaran ditolak. Penyewa dapat mengunggah ulang bukti bayar.");
    } elseif ($aksi == 'reset') {
        if (!empty($d_tagihan['bukti_bayar'])) {
            foreach (['../uploads/pembayaran/', '../uploads/bukti_bayar/'] as $dir) {
                if (is_file($dir . $d_tagihan['bukti_bayar'])) unlink($dir . $d_tagihan['bukti_bayar']);
            }
        }
        $stmt = $conn->prepare("UPDATE tagihan SET status_pembayaran = 'belum_bayar', bukti_bayar = NULL, tanggal_bayar = NULL WHERE id = ?");
        $stmt->bind_param('i', $id_tagihan);
        $stmt->execute();
        $stmt->close();
        $pesan = alert_admin("Status tagihan di-reset menjadi belum bayar untuk periode pembayaran baru.");
    } else {
        $pesan = alert_admin("Aksi tidak dikenali.");
    }
}

// Rekap & daftar tagihan
$query_tagihan = $conn->query(
    "SELECT tagihan.*, users.nama AS nama_penyewa, users.email, kamar.nomor_kamar, kamar.tipe_kamar
     FROM tagihan
     JOIN users ON tagihan.user_id = users.id
     LEFT JOIN kamar ON tagihan.kamar_id = kamar.id
     ORDER BY FIELD(tagihan.status_pembayaran,'menunggu_konfirmasi','belum_bayar','ditolak','lunas'), tagihan.id DESC"
);

$q_rekap = $conn->query(
    "SELECT status_pembayaran, COUNT(*) AS jumlah, SUM(jumlah) AS total
     FROM tagihan GROUP BY status_pembayaran"
);
$rekap = ['menunggu_konfirmasi' => 0, 'belum_bayar' => 0, 'lunas' => 0, 'ditolak' => 0, 'total_lunas' => 0];
while ($r = $q_rekap->fetch_assoc()) {
    $rekap[$r['status_pembayaran']] = (int)$r['jumlah'];
    if ($r['status_pembayaran'] === 'lunas') $rekap['total_lunas'] = (float)$r['total'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfirmasi Pembayaran - Kosmos Admin</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f0f0; color: #111111; margin: 0; padding: 0; }
        .sidebar { width: 250px; background: #111111; color: #ffffff; position: fixed; height: 100%; padding: 20px; box-sizing: border-box; }
        .sidebar h2 { font-size: 20px; letter-spacing: 1px; text-align: center; margin-bottom: 30px; border-bottom: 1px solid #444; padding-bottom: 15px; }
        .sidebar a { display: block; color: #ffffff; text-decoration: none; padding: 10px 15px; margin-bottom: 8px; border-radius: 4px; font-size: 14px; }
        .sidebar a:hover, .sidebar a.active { background: #333333; }
        .sidebar a.logout { background: #ffffff; color: #111111; font-weight: bold; text-align: center; margin-top: 40px; }
        .main-content { margin-left: 250px; padding: 40px; box-sizing: border-box; }
        .card-table { background: #ffffff; padding: 25px; border: 2px solid #111111; border-radius: 6px; box-shadow: 4px 4px 0px #111111; }
        .alert { padding: 12px 15px; background: #111; color: #fff; margin-bottom: 15px; border-radius: 4px; font-size: 13px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #111111; padding: 12px; text-align: left; font-size: 14px; vertical-align: middle; }
        th { background: #111111; color: #ffffff; }
        td:nth-last-child(1), th:nth-last-child(1) { min-width: 140px; }
        .btn-terima, .btn-tolak, .btn-reset {
            display: inline-block; margin-bottom: 4px; margin-right: 3px; padding: 5px 9px;
            text-decoration: none; border-radius: 3px; font-size: 11px; font-weight: bold; text-align: center; box-sizing: border-box;
        }
        .btn-terima { background: #111111; color: #fff; }
        .btn-terima:hover { background: #333; }
        .btn-tolak { background: #666666; color: #fff; }
        .btn-tolak:hover { background: #444; }
        .btn-reset { background: #d9534f; color: #fff; }
        .btn-reset:hover { background: #c9302c; }
        .badge { display: inline-block; padding: 5px 8px; border-radius: 3px; font-size: 10px; font-weight: bold; text-transform: uppercase; white-space: nowrap; }
        .rekap { display: flex; flex-wrap: wrap; gap: 15px; margin-bottom: 25px; }
        .rekap .stat { flex: 1; min-width: 170px; background: #fff; border: 2px solid #111; border-radius: 6px; box-shadow: 4px 4px 0 #111; padding: 18px 20px; }
        .rekap .stat h3 { margin: 0 0 8px 0; font-size: 12px; text-transform: uppercase; color: #666; }
        .rekap .stat p { margin: 0; font-size: 22px; font-weight: bold; }
    </style>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

    <div class="sidebar">
        <h2>KOSMOS ADMIN</h2>
        <a href="dashboard.php">Dashboard Utama</a>
        <a href="kelola-kamar.php">Kelola Kamar</a>
        <a href="verifikasi-penyewa.php">Verifikasi Penyewa</a>
        <a href="konfirmasi-pembayaran.php" class="active">Konfirmasi Bayar</a>
        <a href="kelola-tagihan.php">Kelola Tagihan</a>
        <a href="kelola-inventaris.php">Kelola Inventaris</a>
        <a href="kelola-laporan.php">Kelola Laporan</a>
        <a href="../logout.php" class="logout">LOGOUT</a>
    </div>

    <div class="main-content">
        <h1>Konfirmasi & Kelola Pembayaran</h1>
        <p style="color: #666; margin-bottom: 25px;">Verifikasi bukti pembayaran penyewa atau reset status untuk periode jatuh tempo berikutnya.</p>

        <?= $pesan; ?>

        <div class="rekap">
            <div class="stat"><h3>Menunggu Konfirmasi</h3><p><?= $rekap['menunggu_konfirmasi']; ?></p></div>
            <div class="stat"><h3>Belum Bayar</h3><p><?= $rekap['belum_bayar']; ?></p></div>
            <div class="stat"><h3>Ditolak</h3><p><?= $rekap['ditolak']; ?></p></div>
            <div class="stat"><h3>Total Sudah Lunas</h3><p>Rp <?= number_format($rekap['total_lunas'], 0, ',', '.'); ?></p></div>
        </div>

        <div class="card-table">
            <h2>Daftar Tagihan & Pembayaran</h2>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Penyewa & Kamar</th>
                        <th>Jenis & Periode</th>
                        <th>Jumlah</th>
                        <th>Jatuh Tempo</th>
                        <th>Bukti Bayar</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    if ($query_tagihan && $query_tagihan->num_rows > 0) {
                        while ($row = $query_tagihan->fetch_assoc()) { 
                            $bukti = $row['bukti_bayar'];
                            $url_bukti = "";
                            if (!empty($bukti)) {
                                foreach (['../uploads/pembayaran/', '../uploads/bukti_bayar/'] as $dir) {
                                    if (is_file($dir . $bukti)) { $url_bukti = htmlspecialchars($dir . rawurlencode($bukti)); break; }
                                }
                            }
                            $adalah_pdf = !empty($bukti) && strtolower(pathinfo($bukti, PATHINFO_EXTENSION)) === 'pdf';
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td>
                            <strong><?= htmlspecialchars($row['nama_penyewa']); ?></strong><br>
                            <span style="font-size: 12px; color: #666;"><?= htmlspecialchars($row['email']); ?></span><br>
                            <span style="font-size: 12px; color: #111; font-weight: bold;">Kamar No. <?= htmlspecialchars($row['nomor_kamar']); ?></span>
                        </td>
                        <td>
                            <span class="badge" style="background:#eee; color:#333; border:1px solid #111;"><?= strtoupper(str_replace('_', ' ', $row['jenis'])); ?></span><br>
                            <span style="font-size: 13px;"><?= htmlspecialchars($row['bulan']); ?></span>
                        </td>
                        <td>Rp <?= number_format($row['jumlah'], 0, ',', '.'); ?></td>
                        <td>
                            <?= $row['jatuh_tempo'] ? htmlspecialchars($row['jatuh_tempo']) : '<span style="color:#666;">-</span>'; ?>
                            <?php if ($row['tanggal_bayar']) { ?><br><span style="font-size: 11px; color: #666;">Dibayar: <?= htmlspecialchars($row['tanggal_bayar']); ?></span><?php } ?>
                        </td>
                        <td>
                            <?php if ($adalah_pdf) { ?>
                                <a href="<?= $url_bukti; ?>" target="_blank" style="font-size: 12px; color: #111; font-weight: bold; text-decoration: underline;">Lihat Bukti (PDF)</a>
                            <?php } elseif (!empty($url_bukti)) { ?>
                                <a href="<?= $url_bukti; ?>" target="_blank">
                                    <img src="<?= $url_bukti; ?>" width="80" height="60" style="object-fit: cover; border-radius: 3px; border: 1px solid #111;" title="Klik untuk memperbesar">
                                </a>
                            <?php } else { ?>
                                <span style="font-size: 11px; color: #666;"><?= $bukti ? 'Berkas tidak ditemukan' : 'Belum upload' ?></span>
                            <?php } ?>
                        </td>
                        <td>
                            <?php if ($row['status_pembayaran'] == 'lunas') { ?>
                                <span class="badge" style="background: #111; color: #fff;">Lunas</span>
                            <?php } elseif ($row['status_pembayaran'] == 'ditolak') { ?>
                                <span class="badge" style="background: #ccc; color: #333;">Ditolak</span>
                            <?php } elseif ($row['status_pembayaran'] == 'menunggu_konfirmasi') { ?>
                                <span class="badge" style="background: #eee; color: #333; border: 1px solid #111;">Menunggu Konfirmasi</span>
                            <?php } else { ?>
                                <span class="badge" style="background: #fff; color: #111; border: 1px solid #111;">Belum Bayar</span>
                            <?php } ?>
                        </td>
                        <td>
                            <?php if ($row['status_pembayaran'] !== 'lunas') { ?>
                                <a href="konfirmasi-pembayaran.php?aksi=terima&id=<?= (int)$row['id']; ?>" class="btn-terima" onclick="return confirm('Setujui pembayaran ini?')">Setujui</a>
                                <?php if ($row['status_pembayaran'] !== 'ditolak') { ?>
                                    <a href="konfirmasi-pembayaran.php?aksi=tolak&id=<?= (int)$row['id']; ?>" class="btn-tolak" onclick="return confirm('Tolak pembayaran ini?')">Tolak</a>
                                <?php } ?>
                            <?php } ?>
                            <a href="konfirmasi-pembayaran.php?aksi=reset&id=<?= (int)$row['id']; ?>" class="btn-reset" onclick="return confirm('Reset status tagihan ini menjadi Belum Bayar untuk bulan/periode baru?')">Reset</a>
                        </td>
                    </tr>
                    <?php 
                        }
                    } else { 
                    ?>
                    <tr>
                        <td colspan="8" class="empty-state">Belum ada data tagihan.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>
