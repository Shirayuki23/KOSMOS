<?php
session_start();
include '../koneksi.php';

// Proteksi Halaman Admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$pesan = "";

// Proses Update Status Laporan (pending, diproses, selesai)
if (isset($_GET['aksi']) && isset($_GET['id']) && ctype_digit((string)$_GET['id'])) {
    $id_laporan = (int)$_GET['id'];
    $aksi = $_GET['aksi'];

    $status_baru = ['proses' => 'diproses', 'selesai' => 'selesai'][$aksi] ?? null;

    if ($status_baru === null) {
        $pesan = "<div class='alert'>Aksi tidak dikenali.</div>";
    } else {
        $stmt = $conn->prepare("UPDATE komplain SET status_laporan = ? WHERE id = ?");
        $stmt->bind_param('si', $status_baru, $id_laporan);
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $pesan = "<div class='alert'>Status laporan diubah menjadi " . strtoupper($status_baru) . ".</div>";
        } else {
            $pesan = "<div class='alert'>Laporan tidak ditemukan atau status sudah sesuai.</div>";
        }
        $stmt->close();
    }
}

// Ambil daftar semua laporan dari penyewa dengan JOIN ke users dan kamar
$query_laporan = $conn->query("
    SELECT komplain.*, users.nama AS nama_penyewa, users.no_hp, kamar.nomor_kamar 
    FROM komplain 
    JOIN users ON komplain.user_id = users.id 
    LEFT JOIN kamar ON users.id_kamar = kamar.id 
    ORDER BY FIELD(komplain.status_laporan,'pending','diproses','selesai'), komplain.id DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Laporan Kerusakan - Kosmos Admin</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f0f0; color: #111111; margin: 0; padding: 0; }
        .sidebar { width: 250px; background: #111111; color: #ffffff; position: fixed; height: 100%; padding: 20px; box-sizing: border-box; }
        .sidebar h2 { font-size: 20px; letter-spacing: 1px; text-align: center; margin-bottom: 30px; border-bottom: 1px solid #444; padding-bottom: 15px; }
        .sidebar a { display: block; color: #ffffff; text-decoration: none; padding: 10px 15px; margin-bottom: 8px; border-radius: 4px; font-size: 14px; }
        .sidebar a:hover, .sidebar a.active { background: #333333; }
        .sidebar a.logout { background: #ffffff; color: #111111; font-weight: bold; text-align: center; margin-top: 40px; }
        .main-content { margin-left: 250px; padding: 40px; box-sizing: border-box; }
        .card-table { background: #ffffff; padding: 25px; border: 2px solid #111111; border-radius: 6px; box-shadow: 4px 4px 0px #111111; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #111111; padding: 12px; text-align: left; font-size: 14px; vertical-align: middle; }
        th { background: #111111; color: #ffffff; }
        tr:nth-child(even) { background: #f9f9f9; }
        
        .btn-proses { background: #d9534f; color: #fff; padding: 5px 10px; text-decoration: none; border-radius: 3px; font-size: 11px; font-weight: bold; display: inline-block; margin-right: 3px; margin-bottom: 3px; }
        .btn-selesai { background: #111; color: #fff; padding: 5px 10px; text-decoration: none; border-radius: 3px; font-size: 11px; font-weight: bold; display: inline-block; margin-bottom: 3px; }
        .btn-proses:hover { background: #c9302c; }
        .btn-selesai:hover { background: #333; }
        
        .badge { padding: 4px 8px; border-radius: 3px; font-size: 10px; font-weight: bold; text-transform: uppercase; white-space: nowrap; }
        .alert { padding: 12px 15px; background: #111; color: #fff; margin-bottom: 15px; border-radius: 4px; font-size: 13px; }
    </style>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

    <div class="sidebar">
        <h2>KOSMOS ADMIN</h2>
        <a href="dashboard.php">Dashboard Utama</a>
        <a href="kelola-kamar.php">Kelola Kamar</a>
        <a href="verifikasi-penyewa.php">Verifikasi Penyewa</a>
        <a href="konfirmasi-pembayaran.php">Konfirmasi Bayar</a>
        <a href="kelola-tagihan.php">Kelola Tagihan</a>
        <a href="kelola-inventaris.php">Kelola Inventaris</a>
        <a href="kelola-laporan.php" class="active">Kelola Laporan</a>
        <a href="../logout.php" class="logout">LOGOUT</a>
    </div>

    <div class="main-content">
        <h1>Kelola Laporan Kerusakan</h1>
        <p style="color: #666; margin-bottom: 25px;">Daftar kendala fasilitas yang dilaporkan oleh para penghuni kos.</p>

        <?= $pesan; ?>

        <div class="card-table">
            <h2>Daftar Laporan Masuk</h2>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Penyewa & Kamar</th>
                        <th>Judul & Deskripsi Kendala</th>
                        <th>Waktu</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    if ($query_laporan && mysqli_num_rows($query_laporan) > 0) {
                        while ($row = mysqli_fetch_assoc($query_laporan)) {
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td>
                            <strong><?= htmlspecialchars($row['nama_penyewa']); ?></strong><br>
                            <span style="font-size: 12px; color: #666;">No HP: <?= htmlspecialchars($row['no_hp']); ?></span><br>
                            <span style="font-size: 12px; color: #111; font-weight: bold;">Kamar No. <?= htmlspecialchars($row['nomor_kamar'] ?? '-'); ?></span>
                        </td>
                        <td>
                            <strong><?= htmlspecialchars($row['judul_laporan']); ?></strong><br>
                            <span style="font-size: 13px; color: #555;"><?= htmlspecialchars($row['deskripsi']); ?></span>
                        </td>
                        <td style="font-size: 12px; color: #666;"><?= htmlspecialchars($row['tanggal_laporan']); ?></td>
                        <td>
                            <?php if ($row['status_laporan'] == 'selesai') { ?>
                                <span class="badge" style="background: #28a745; color: #fff;">Selesai</span>
                            <?php } elseif ($row['status_laporan'] == 'diproses') { ?>
                                <span class="badge" style="background: #f0ad4e; color: #fff;">Diproses</span>
                            <?php } else { ?>
                                <span class="badge" style="background: #111; color: #fff;">Pending</span>
                            <?php } ?>
                        </td>
                        <td>
                            <a href="kelola-laporan.php?aksi=proses&id=<?= $row['id']; ?>" class="btn-proses" onclick="return confirm('Ubah status menjadi diproses?')">Diproses</a>
                            <a href="kelola-laporan.php?aksi=selesai&id=<?= $row['id']; ?>" class="btn-selesai" onclick="return confirm('Tandai laporan ini sudah selesai?')">Selesai</a>
                        </td>
                    </tr>
                    <?php 
                        }
                    } else {
                    ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: #666; padding: 20px;">Belum ada laporan kerusakan dari penyewa.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>