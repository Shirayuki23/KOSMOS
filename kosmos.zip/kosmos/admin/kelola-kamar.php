<?php
session_start();
include '../koneksi.php';

// Proteksi Halaman Admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$pesan = "";
$status_valid = ['tersedia', 'terisi', 'maintenance'];

// ==== Helper unggah foto kamar (ekstensi + MIME + ukuran maks 2 MB) ====
function proses_foto_kamar($file, $dir_tujuan, &$pesan, &$error) {
    if (empty($file['name'])) {
        return null; // tidak ada unggahan
    }
    if (!is_dir($dir_tujuan)) {
        mkdir($dir_tujuan, 0777, true);
    }
    $ekstensi = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = $finfo->file($file['tmp_name']);
    if (!in_array($ekstensi, ['jpg', 'jpeg', 'png'], true) || !in_array($mime, ['image/jpeg', 'image/png'], true)) {
        $error = 'Format foto harus JPG, JPEG, atau PNG.';
        return null;
    }
    if ($file['size'] > 2 * 1024 * 1024) {
        $error = 'Ukuran foto melebihi batas 2 MB.';
        return null;
    }
    $nama_baru = uniqid() . '.' . $ekstensi;
    if (!move_uploaded_file($file['tmp_name'], $dir_tujuan . $nama_baru)) {
        $error = 'Gagal menyimpan file foto.';
        return null;
    }
    return $nama_baru;
}

// ==== 1. PROSES TAMBAH KAMAR ====
if (isset($_POST['tambah_kamar'])) {
    $nomor_kamar = trim($_POST['nomor_kamar']);
    $tipe_kamar  = trim($_POST['tipe_kamar']);
    $harga       = $_POST['harga'];
    $fasilitas   = trim($_POST['fasilitas']);
    $status      = $_POST['status'];

    $error_foto = '';
    $nama_file_baru = proses_foto_kamar($_FILES['foto'], "../uploads/kamar/", $pesan, $error_foto);
    if ($error_foto !== '') {
        $pesan = "<div class='alert'>$error_foto</div>";
    } elseif (!in_array($status, $status_valid, true) || $nomor_kamar === '' || !is_numeric($harga)) {
        $pesan = "<div class='alert'>Data kamar tidak valid. Periksa nomor, tipe, harga, dan status.</div>";
    } else {
        $harga = (float) $harga;
        $stmt = $conn->prepare("INSERT INTO kamar (nomor_kamar, tipe_kamar, harga, fasilitas, status, foto)
                                VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('ssdsss', $nomor_kamar, $tipe_kamar, $harga, $fasilitas, $status, $nama_file_baru);
        if ($stmt->execute()) {
            $pesan = "<div class='alert alert-ok'>Kamar baru berhasil ditambahkan!</div>";
        } else {
            $pesan = "<div class='alert'>Gagal menambah kamar.</div>";
        }
    }
}

// ==== 2. PROSES UBAH DATA / STATUS KAMAR (FR-07) ====
if (isset($_POST['update_kamar'])) {
    $id_kamar = (int) $_POST['id'];
    $nomor_kamar = trim($_POST['nomor_kamar']);
    $tipe_kamar  = trim($_POST['tipe_kamar']);
    $harga       = (float) $_POST['harga'];
    $fasilitas   = trim($_POST['fasilitas']);
    $status      = $_POST['status'];

    $error_foto = '';
    $nama_file_baru = proses_foto_kamar($_FILES['foto'], "../uploads/kamar/", $pesan, $error_foto);
    if ($error_foto !== '') {
        $pesan = "<div class='alert'>$error_foto</div>";
    } elseif (!in_array($status, $status_valid, true) || $nomor_kamar === '') {
        $pesan = "<div class='alert'>Data kamar tidak valid. Perubahan tidak disimpan.</div>";
    } else {
        if ($nama_file_baru === null) {
            // tidak ada foto baru: pertahankan foto lama
            $stmt = $conn->prepare("UPDATE kamar SET nomor_kamar=?, tipe_kamar=?, harga=?, fasilitas=?, status=? WHERE id=?");
            $stmt->bind_param('ssdssi', $nomor_kamar, $tipe_kamar, $harga, $fasilitas, $status, $id_kamar);
        } else {
            $stmt = $conn->prepare("UPDATE kamar SET nomor_kamar=?, tipe_kamar=?, harga=?, fasilitas=?, status=?, foto=? WHERE id=?");
            $stmt->bind_param('ssdsssi', $nomor_kamar, $tipe_kamar, $harga, $fasilitas, $status, $nama_file_baru, $id_kamar);
        }
        if ($stmt->execute()) {
            $pesan = "<div class='alert alert-ok'>Kamar No. $nomor_kamar berhasil diperbarui (status: $status).</div>";
        } else {
            $pesan = "<div class='alert'>Gagal memperbarui kamar.</div>";
        }
    }
}

// ==== 3. PROSES HAPUS KAMAR ====
if (isset($_GET['hapus']) && ctype_digit((string) $_GET['hapus'])) {
    $id_kamar = (int) $_GET['hapus'];

    $stmt_cari = $conn->prepare("SELECT nomor_kamar, foto FROM kamar WHERE id = ?");
    $stmt_cari->bind_param('i', $id_kamar);
    $stmt_cari->execute();
    $d_kamar = $stmt_cari->get_result()->fetch_assoc();

    $stmt_penghuni = $conn->prepare("SELECT nama FROM users WHERE id_kamar = ? AND status_akun != 'ditolak' LIMIT 1");
    $stmt_penghuni->bind_param('i', $id_kamar);
    $stmt_penghuni->execute();
    $d_penghuni = $stmt_penghuni->get_result()->fetch_assoc();

    if (!$d_kamar) {
        $pesan = "<div class='alert'>Kamar tidak ditemukan.</div>";
    } elseif ($d_penghuni) {
        $pesan = "<div class='alert'>Kamar No. " . htmlspecialchars($d_kamar['nomor_kamar'])
               . " masih ditempati " . htmlspecialchars($d_penghuni['nama'])
               . ". Pindahkan atau tolak penyewa tersebut sebelum menghapus kamar.</div>";
    } else {
        $stmt_hapus = $conn->prepare("DELETE FROM kamar WHERE id = ?");
        $stmt_hapus->bind_param('i', $id_kamar);
        if ($stmt_hapus->execute()) {
            if (!empty($d_kamar['foto']) && file_exists("../uploads/kamar/" . $d_kamar['foto'])) {
                unlink("../uploads/kamar/" . $d_kamar['foto']);
            }
            header("Location: kelola-kamar.php");
            exit;
        }
        $pesan = "<div class='alert'>Gagal menghapus kamar (kemungkinan masih memiliki relasi data).</div>";
    }
}

// ==== Data untuk tampilan ====
$edit_kamar = null;
if (isset($_GET['edit']) && ctype_digit((string) $_GET['edit'])) {
    $id_edit = (int) $_GET['edit'];
    $stmt_edit = $conn->prepare("SELECT * FROM kamar WHERE id = ?");
    $stmt_edit->bind_param('i', $id_edit);
    $stmt_edit->execute();
    $edit_kamar = $stmt_edit->get_result()->fetch_assoc();
}

$result_kamar = $conn->query("SELECT * FROM kamar ORDER BY nomor_kamar ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kelola Kamar - Kosmos Admin</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f0f0; color: #111111; margin: 0; padding: 0; }
        .sidebar { width: 250px; background: #111111; color: #ffffff; position: fixed; height: 100%; padding: 20px; box-sizing: border-box; }
        .sidebar h2 { font-size: 20px; letter-spacing: 1px; text-align: center; margin-bottom: 30px; border-bottom: 1px solid #444; padding-bottom: 15px; }
        .sidebar a { display: block; color: #ffffff; text-decoration: none; padding: 10px 15px; margin-bottom: 8px; border-radius: 4px; font-size: 14px; }
        .sidebar a:hover, .sidebar a.active { background: #333333; }
        .sidebar a.logout { background: #ffffff; color: #111111; font-weight: bold; text-align: center; margin-top: 40px; }
        .main-content { margin-left: 250px; padding: 40px; box-sizing: border-box; }
        .card-form, .card-table { background: #ffffff; padding: 25px; border: 2px solid #111111; border-radius: 6px; box-shadow: 4px 4px 0px #111111; margin-bottom: 30px; }
        h2 { margin-top: 0; }
        label { font-weight: 600; font-size: 13px; color: #333; }
        input[type="text"], input[type="number"], textarea, select, input[type="file"] {
            width: 100%; padding: 9px; margin: 5px 0 15px 0; border: 1.5px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size: 14px;
        }
        button[type="submit"] { background: #111111; color: #ffffff; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: bold; font-size: 14px; }
        button[type="submit"]:hover { background: #333333; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #111111; padding: 10px; text-align: left; font-size: 14px; vertical-align: middle; }
        th { background: #111111; color: #ffffff; }
        tr:nth-child(even) { background: #f9f9f9; }
        .btn-hapus { background: #111111; color: #fff; padding: 5px 10px; text-decoration: none; border-radius: 3px; font-size: 12px; font-weight: bold; }
        .btn-hapus:hover { background: #444; }
        .btn-edit { background: #fff; color: #111; border: 1.5px solid #111; padding: 4px 9px; text-decoration: none; border-radius: 3px; font-size: 12px; font-weight: bold; display: inline-block; margin-bottom: 4px; }
        .btn-edit:hover { background: #111; color: #fff; }
        .alert { padding: 12px 14px; background: #111; color: #fff; margin-bottom: 15px; border-radius: 4px; font-size: 13px; }
        .alert-ok { background: #fff; color: #111; border: 2px solid #111; }
        .form-aksi { display: flex; gap: 6px; align-items: center; }
        .form-aksi select { width: auto; margin: 0; padding: 5px 8px; font-size: 12px; }
        .form-aksi button { padding: 5px 10px; font-size: 12px; }
    </style>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

    <div class="sidebar">
        <h2>KOSMOS ADMIN</h2>
        <a href="dashboard.php">Dashboard Utama</a>
        <a href="kelola-kamar.php" class="active">Kelola Kamar</a>
        <a href="verifikasi-penyewa.php">Verifikasi Penyewa</a>
        <a href="konfirmasi-pembayaran.php">Konfirmasi Pembayaran</a>
        <a href="kelola-tagihan.php">Kelola Tagihan</a>
        <a href="kelola-inventaris.php">Kelola Inventaris</a>
        <a href="kelola-laporan.php">Kelola Laporan</a>
        <a href="../logout.php" class="logout">LOGOUT</a>
    </div>

    <div class="main-content">
        <h1>Kelola Kamar Kos</h1>
        <p style="color: #666; margin-bottom: 25px;">Tambah, ubah, atau hapus data kamar kos yang tersedia.</p>

        <?= $pesan; ?>

        <div class="card-form">
            <h2><?= $edit_kamar ? 'Ubah Kamar No. ' . htmlspecialchars($edit_kamar['nomor_kamar']) : 'Tambah Kamar Baru'; ?></h2>
            <form action="" method="POST" enctype="multipart/form-data">
                <?php if ($edit_kamar) { ?>
                    <input type="hidden" name="id" value="<?= (int) $edit_kamar['id']; ?>">
                <?php } ?>

                <label>Nomor Kamar</label>
                <input type="text" name="nomor_kamar" placeholder="Contoh: 01, 02, A1" required
                       value="<?= $edit_kamar ? htmlspecialchars($edit_kamar['nomor_kamar']) : ''; ?>">

                <label>Tipe Kamar</label>
                <input type="text" name="tipe_kamar" placeholder="Contoh: Standar, Deluxe, AC" required
                       value="<?= $edit_kamar ? htmlspecialchars($edit_kamar['tipe_kamar']) : ''; ?>">

                <label>Harga per Bulan (Rp)</label>
                <input type="number" name="harga" placeholder="Contoh: 750000" required
                       value="<?= $edit_kamar ? htmlspecialchars($edit_kamar['harga']) : ''; ?>">

                <label>Fasilitas</label>
                <textarea name="fasilitas" rows="3" placeholder="Contoh: Kasur, Lemari, Kamar Mandi Dalam, AC" required><?= $edit_kamar ? htmlspecialchars($edit_kamar['fasilitas']) : ''; ?></textarea>

                <label>Status Kamar</label>
                <select name="status" required>
                    <?php foreach (['tersedia', 'terisi', 'maintenance'] as $opsi): ?>
                        <option value="<?= $opsi; ?>" <?= ($edit_kamar && $edit_kamar['status'] === $opsi) ? 'selected' : ''; ?>>
                            <?= ucfirst($opsi); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label>Foto Kamar (JPG / PNG, maks. 2 MB)<?= $edit_kamar ? ' — kosongkan jika tidak diganti' : ''; ?></label>
                <input type="file" name="foto" accept=".jpg,.jpeg,.png" <?= $edit_kamar ? '' : 'required'; ?>>
                <?php if ($edit_kamar && !empty($edit_kamar['foto'])) { ?>
                    <p style="font-size:12px; color:#666; margin:-10px 0 14px 0;">
                        Foto saat ini: <img src="../uploads/kamar/<?= htmlspecialchars($edit_kamar['foto']); ?>" width="90" style="vertical-align:middle; border:1px solid #111;">
                    </p>
                <?php } ?>

                <button type="submit" name="<?= $edit_kamar ? 'update_kamar' : 'tambah_kamar'; ?>">
                    <?= $edit_kamar ? 'SIMPAN PERUBAHAN' : 'SIMPAN KAMAR BARU'; ?>
                </button>
                <?php if ($edit_kamar) { ?>
                    <a href="kelola-kamar.php" class="btn-edit" style="margin-left:8px;">Batal / Form Tambah</a>
                <?php } ?>
            </form>
        </div>

        <div class="card-table">
            <h2>Daftar Seluruh Kamar</h2>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Foto</th>
                        <th>No. Kamar</th>
                        <th>Tipe & Harga</th>
                        <th>Fasilitas</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    if (mysqli_num_rows($result_kamar) > 0) {
                        while ($row = mysqli_fetch_assoc($result_kamar)) { 
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td>
                            <?php if (!empty($row['foto'])) { ?>
                                <img src="../uploads/kamar/<?= htmlspecialchars($row['foto']); ?>" width="70" height="50" style="object-fit: cover; border-radius: 3px; border: 1px solid #111;">
                            <?php } else { ?>
                                <span style="font-size: 11px; color: #666;">Tidak ada foto</span>
                            <?php } ?>
                        </td>
                        <td><strong><?= htmlspecialchars($row['nomor_kamar']); ?></strong></td>
                        <td>
                            <?= htmlspecialchars($row['tipe_kamar']); ?><br>
                            <strong>Rp <?= number_format($row['harga'], 0, ',', '.'); ?></strong>
                        </td>
                        <td><?= htmlspecialchars($row['fasilitas']); ?></td>
                        <td>
                            <span style="padding: 3px 8px; border-radius: 3px; font-size: 12px; font-weight: bold; background: <?= ($row['status'] == 'tersedia') ? '#111; color: #fff;' : '#ccc; color: #000;'; ?>">
                                <?= strtoupper($row['status']); ?>
                            </span>
                        </td>
                        <td>
                            <a href="kelola-kamar.php?edit=<?= (int) $row['id']; ?>" class="btn-edit">Ubah</a><br>
                            <a href="kelola-kamar.php?hapus=<?= (int) $row['id']; ?>" class="btn-hapus" onclick="return confirm('Yakin ingin menghapus kamar ini?')">Hapus</a>
                        </td>
                    </tr>
                    <?php 
                        }
                    } else { 
                    ?>
                    <tr>
                        <td colspan="7" style="text-align: center; color: #666; padding: 20px;">Belum ada data kamar.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>