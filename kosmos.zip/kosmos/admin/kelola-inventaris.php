<?php
session_start();
include '../koneksi.php';

// Proteksi Halaman Admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$pesan = "";

function alert_admin($teks) {
    return "<div class='alert'>" . htmlspecialchars($teks) . "</div>";
}

$lokasi_valid  = ['kamar', 'area_bersama'];
$kondisi_valid = ['baik', 'perlu_perbaikan', 'rusak'];

function validasi_inventaris($nama_barang, $lokasi, $kondisi, $jumlah, $kamar_id, $conn) {
    $validasi = [];
    if (strlen($nama_barang) < 3 || strlen($nama_barang) > 100) $validasi[] = "Nama barang harus 3-100 karakter.";
    if (!in_array($lokasi, ['kamar', 'area_bersama'], true)) $validasi[] = "Lokasi tidak valid.";
    if (!in_array($kondisi, ['baik', 'perlu_perbaikan', 'rusak'], true)) $validasi[] = "Kondisi tidak valid.";
    if ($jumlah < 1 || $jumlah > 999) $validasi[] = "Jumlah harus antara 1 dan 999.";
    if ($lokasi === 'kamar') {
        if (empty($kamar_id)) {
            $validasi[] = "Barang di dalam kamar wajib ditautkan ke satu kamar.";
        } else {
            $stmt = $conn->prepare("SELECT id FROM kamar WHERE id = ?");
            $stmt->bind_param('i', $kamar_id);
            $stmt->execute();
            if (!$stmt->get_result()->fetch_assoc()) $validasi[] = "Kamar yang ditautkan tidak ditemukan.";
            $stmt->close();
        }
    }
    return $validasi;
}

// 1. TAMBAH / UBAH INVENTARIS
if (isset($_POST['simpan_inventaris'])) {
    $id_inventaris = (int)$_POST['id_inventaris'];
    $nama_barang   = trim($_POST['nama_barang']);
    $lokasi        = $_POST['lokasi'];
    $kamar_id      = ($lokasi === 'kamar' && $_POST['kamar_id'] !== '') ? (int)$_POST['kamar_id'] : null;
    $kondisi       = $_POST['kondisi'];
    $jumlah        = (int)$_POST['jumlah'];

    $validasi = validasi_inventaris($nama_barang, $lokasi, $kondisi, $jumlah, $kamar_id, $conn);

    if (!empty($validasi)) {
        $pesan = alert_admin(implode(" ", $validasi));
    } elseif ($id_inventaris > 0) {
        $stmt = $conn->prepare("UPDATE inventaris SET nama_barang = ?, lokasi = ?, kamar_id = ?, kondisi = ?, jumlah = ? WHERE id = ?");
        $stmt->bind_param('ssisii', $nama_barang, $lokasi, $kamar_id, $kondisi, $jumlah, $id_inventaris);
        $pesan = $stmt->execute() ? alert_admin("Data inventaris berhasil diperbarui.") : alert_admin("Gagal memperbarui: " . $conn->error);
        $stmt->close();
    } else {
        $stmt = $conn->prepare("INSERT INTO inventaris (nama_barang, lokasi, kamar_id, kondisi, jumlah) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param('ssssi', $nama_barang, $lokasi, $kamar_id, $kondisi, $jumlah);
        $pesan = $stmt->execute() ? alert_admin("Barang inventaris berhasil ditambahkan.") : alert_admin("Gagal menambahkan: " . $conn->error);
        $stmt->close();
    }
}

// 2. HAPUS INVENTARIS
if (isset($_GET['hapus']) && ctype_digit((string)$_GET['hapus'])) {
    $stmt = $conn->prepare("DELETE FROM inventaris WHERE id = ?");
    $id_inventaris = (int)$_GET['hapus'];
    $stmt->bind_param('i', $id_inventaris);
    $stmt->execute();
    $pesan = $stmt->affected_rows > 0
        ? alert_admin("Barang inventaris berhasil dihapus.")
        : alert_admin("Barang inventaris tidak ditemukan.");
    $stmt->close();
}

// 3. MODE EDIT
$edit_inventaris = null;
if (isset($_GET['edit']) && ctype_digit((string)$_GET['edit'])) {
    $stmt = $conn->prepare("SELECT * FROM inventaris WHERE id = ?");
    $id_edit = (int)$_GET['edit'];
    $stmt->bind_param('i', $id_edit);
    $stmt->execute();
    $edit_inventaris = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$edit_inventaris) {
        header("Location: kelola-inventaris.php");
        exit;
    }
}

$kamar_list = [];
$q_kamar = $conn->query("SELECT id, nomor_kamar, tipe_kamar FROM kamar ORDER BY nomor_kamar ASC");
while ($k = $q_kamar->fetch_assoc()) $kamar_list[] = $k;

$query_inventaris = $conn->query(
    "SELECT i.*, k.nomor_kamar
     FROM inventaris i LEFT JOIN kamar k ON i.kamar_id = k.id
     ORDER BY i.lokasi ASC, k.nomor_kamar ASC, i.nama_barang ASC"
);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Inventaris - Kosmos Admin</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f0f0; color: #111111; margin: 0; padding: 0; }
        .sidebar { width: 250px; background: #111111; color: #ffffff; position: fixed; height: 100%; padding: 20px; box-sizing: border-box; }
        .sidebar h2 { font-size: 20px; letter-spacing: 1px; text-align: center; margin-bottom: 30px; border-bottom: 1px solid #444; padding-bottom: 15px; }
        .sidebar a { display: block; color: #ffffff; text-decoration: none; padding: 10px 15px; margin-bottom: 8px; border-radius: 4px; font-size: 14px; }
        .sidebar a:hover, .sidebar a.active { background: #333333; }
        .sidebar a.logout { background: #ffffff; color: #111111; font-weight: bold; text-align: center; margin-top: 40px; }
        .main-content { margin-left: 250px; padding: 40px; box-sizing: border-box; }
        .card-form, .card-table { background: #ffffff; padding: 25px; border: 2px solid #111111; border-radius: 6px; box-shadow: 4px 4px 0px #111111; margin-bottom: 30px; }
        h2 { margin-top: 0; }
        label { font-weight: 600; font-size: 13px; color: #333; }
        input[type="text"], input[type="number"], select { width: 100%; padding: 10px; margin: 6px 0 15px 0; border: 1.5px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size: 14px; }
        input:focus, select:focus { border-color: #111; outline: none; }
        button[type="submit"] { background: #111111; color: #ffffff; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: bold; font-size: 14px; }
        button[type="submit"]:hover { background: #333333; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #111111; padding: 10px; text-align: left; font-size: 14px; vertical-align: middle; }
        th { background: #111111; color: #ffffff; }
        .badge { padding: 4px 8px; border-radius: 3px; font-size: 11px; font-weight: bold; text-transform: uppercase; }
        .alert { padding: 12px 15px; background: #111; color: #fff; margin-bottom: 15px; border-radius: 4px; font-size: 13px; }
        .btn-edit { background: #fff; color: #111; border: 1.5px solid #111; padding: 5px 11px; text-decoration: none; border-radius: 3px; font-size: 12px; font-weight: bold; display: inline-block; margin-right: 4px; }
        .btn-edit:hover { background: #111; color: #fff; }
        .btn-hapus { background: #666; color: #fff; border: 1.5px solid #111; padding: 5px 11px; text-decoration: none; border-radius: 3px; font-size: 12px; font-weight: bold; display: inline-block; }
        .btn-hapus:hover { background: #111; }
        .btn-batal { background: transparent; color: #111; border: 1.5px solid #111; padding: 10px 20px; border-radius: 4px; text-decoration: none; font-weight: bold; font-size: 14px; display: inline-block; margin-left: 8px; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 0 20px; }
    </style>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

    <div class="sidebar">
        <h2>KOSMOS ADMIN</h2>
        <a href="dashboard.php">Dashboard Utama</a>
        <a href="kelola-kamar.php">Kelola Kamar</a>
        <a href="verifikasi-penyewa.php">Verifikasi Penyewa</a>
        <a href="konfirmasi-pembayaran.php">Konfirmasi Pembayaran</a>
        <a href="kelola-tagihan.php">Kelola Tagihan</a>
        <a href="kelola-inventaris.php" class="active">Kelola Inventaris</a>
        <a href="kelola-laporan.php">Kelola Laporan</a>
        <a href="../logout.php" class="logout">LOGOUT</a>
    </div>

    <div class="main-content">
        <h1>Kelola Inventaris</h1>
        <p style="color: #666; margin-bottom: 25px;">Catat fasilitas di dalam kamar maupun area bersama beserta kondisi dan jumlahnya.</p>

        <?= $pesan; ?>

        <div class="card-form">
            <h2><?= $edit_inventaris ? "Ubah Barang Inventaris" : "Tambah Barang Inventaris" ?></h2>
            <form action="" method="POST">
                <input type="hidden" name="id_inventaris" value="<?= $edit_inventaris ? (int)$edit_inventaris['id'] : 0; ?>">

                <label>Nama Barang</label>
                <input type="text" name="nama_barang" value="<?= $edit_inventaris ? htmlspecialchars($edit_inventaris['nama_barang']) : '' ?>" placeholder="Contoh: AC Split 1/2 PK" maxlength="100" required>

                <div class="grid-2">
                    <div>
                        <label>Lokasi</label>
                        <select name="lokasi" id="select_lokasi">
                            <option value="kamar" <?= $edit_inventaris && $edit_inventaris['lokasi'] === 'kamar' ? 'selected' : '' ?>>Di Dalam Kamar</option>
                            <option value="area_bersama" <?= $edit_inventaris && $edit_inventaris['lokasi'] === 'area_bersama' ? 'selected' : '' ?>>Area Bersama</option>
                        </select>
                    </div>
                    <div id="wrapper_kamar">
                        <label>Tautkan Kamar</label>
                        <select name="kamar_id" id="select_kamar">
                            <option value="">-- Pilih Kamar --</option>
                            <?php foreach ($kamar_list as $k) { ?>
                                <option value="<?= (int)$k['id']; ?>" <?= $edit_inventaris && $edit_inventaris['kamar_id'] == $k['id'] ? 'selected' : '' ?>>
                                    No. <?= htmlspecialchars($k['nomor_kamar']); ?> - <?= htmlspecialchars($k['tipe_kamar']); ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <div class="grid-2">
                    <div>
                        <label>Kondisi</label>
                        <select name="kondisi">
                            <option value="baik" <?= $edit_inventaris && $edit_inventaris['kondisi'] === 'baik' ? 'selected' : '' ?>>Baik</option>
                            <option value="perlu_perbaikan" <?= $edit_inventaris && $edit_inventaris['kondisi'] === 'perlu_perbaikan' ? 'selected' : '' ?>>Perlu Perbaikan</option>
                            <option value="rusak" <?= $edit_inventaris && $edit_inventaris['kondisi'] === 'rusak' ? 'selected' : '' ?>>Rusak</option>
                        </select>
                    </div>
                    <div>
                        <label>Jumlah</label>
                        <input type="number" name="jumlah" min="1" max="999" value="<?= $edit_inventaris ? (int)$edit_inventaris['jumlah'] : 1 ?>" required>
                    </div>
                </div>

                <button type="submit" name="simpan_inventaris"><?= $edit_inventaris ? 'SIMPAN PERUBAHAN' : 'TAMBAH BARANG' ?></button>
                <?php if ($edit_inventaris) { ?><a href="kelola-inventaris.php" class="btn-batal">BATAL</a><?php } ?>
            </form>
        </div>

        <div class="card-table">
            <h2>Daftar Inventaris</h2>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Lokasi</th>
                        <th>Kondisi</th>
                        <th>Jumlah</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    if ($query_inventaris && $query_inventaris->num_rows > 0) {
                        while ($row = $query_inventaris->fetch_assoc()) { 
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><strong><?= htmlspecialchars($row['nama_barang']); ?></strong></td>
                        <td>
                            <?php if ($row['lokasi'] === 'kamar') { ?>
                                Kamar No. <?= htmlspecialchars($row['nomor_kamar']); ?>
                            <?php } else { ?>
                                Area Bersama
                            <?php } ?>
                        </td>
                        <td>
                            <?php $bg = ['baik' => '#111; color:#fff;', 'perlu_perbaikan' => '#eee; color:#333; border:1px solid #111;', 'rusak' => '#ccc; color:#333;']; ?>
                            <span class="badge" style="background:<?= $bg[$row['kondisi']] ?? '#fff; color:#111; border:1px solid #111;' ?>"><?= strtoupper(str_replace('_', ' ', $row['kondisi'])); ?></span>
                        </td>
                        <td><?= (int)$row['jumlah']; ?></td>
                        <td>
                            <a href="kelola-inventaris.php?edit=<?= (int)$row['id']; ?>" class="btn-edit">Ubah</a>
                            <a href="kelola-inventaris.php?hapus=<?= (int)$row['id']; ?>" class="btn-hapus" onclick="return confirm('Hapus barang ini?')">Hapus</a>
                        </td>
                    </tr>
                    <?php 
                        }
                    } else { 
                    ?>
                    <tr>
                        <td colspan="6" class="empty-state">Belum ada data inventaris.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Kamar hanya wajib ditautkan ketika lokasi berada di dalam kamar.
        var selectLokasi = document.getElementById('select_lokasi');
        var selectKamar = document.getElementById('select_kamar');
        var wrapperKamar = document.getElementById('wrapper_kamar');

        function sinkronLokasi() {
            var pakaiKamar = selectLokasi.value === 'kamar';
            wrapperKamar.style.display = pakaiKamar ? '' : 'none';
            selectKamar.required = pakaiKamar;
            if (!pakaiKamar) selectKamar.value = '';
        }
        selectLokasi.addEventListener('change', sinkronLokasi);
        sinkronLokasi();
    </script>

</body>
</html>
