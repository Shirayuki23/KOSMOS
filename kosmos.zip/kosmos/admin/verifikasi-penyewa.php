<?php
session_start();
include '../koneksi.php';

// Proteksi Halaman Admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$pesan = "";

function alert_admin($teks) {
    return "<div class='alert'>" . htmlspecialchars($teks) . "</div>";
}

// Kamar yang sedang ditempati penghuni lain (untuk mencegah dobel assignment)
function kamar_terpakai_lain($conn, $id_kamar, $kecuali_user_id) {
    $stmt = $conn->prepare("SELECT id, nama FROM users WHERE id_kamar = ? AND id != ? AND status_akun != 'ditolak' LIMIT 1");
    $stmt->bind_param('ii', $id_kamar, $kecuali_user_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row;
}

// Lepas penghuni lama dari sebuah kamar bila kamar dipindahtangankan
function lepas_penghuni_lama($conn, $id_kamar, $kecuali_user_id) {
    $stmt = $conn->prepare("UPDATE users SET id_kamar = NULL WHERE id_kamar = ? AND id != ?");
    $stmt->bind_param('ii', $id_kamar, $kecuali_user_id);
    $stmt->execute();
    $stmt->close();
}

// 1. PROSES VERIFIKASI (TERIMA / TOLAK PENYEWA)
if (isset($_GET['aksi']) && isset($_GET['id']) && ctype_digit((string)$_GET['id'])) {
    $id_user = (int)$_GET['id'];
    $aksi = $_GET['aksi'];

    if ($aksi == 'terima') {
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ? AND role != 'admin'");
        $stmt->bind_param('i', $id_user);
        $stmt->execute();
        $d_user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$d_user) {
            $pesan = alert_admin("Akun penyewa tidak ditemukan.");
        } else {
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare("UPDATE users SET status_akun = 'aktif' WHERE id = ?");
                $stmt->bind_param('i', $id_user);
                $stmt->execute();
                $stmt->close();

                if (!empty($d_user['id_kamar'])) {
                    $id_kamar = (int)$d_user['id_kamar'];
                    $penghuni_lain = kamar_terpakai_lain($conn, $id_kamar, $id_user);
                    if ($penghuni_lain) {
                        throw new Exception("Kamar sudah ditempati " . $penghuni_lain['nama'] . ". Tetapkan kamar lain lewat form Data Penyewa.");
                    }
                    lepas_penghuni_lama($conn, $id_kamar, $id_user);
                    $stmt = $conn->prepare("UPDATE kamar SET status = 'terisi' WHERE id = ?");
                    $stmt->bind_param('i', $id_kamar);
                    $stmt->execute();
                    $stmt->close();
                }
                $conn->commit();
                $pesan = alert_admin("Penyewa berhasil diverifikasi (Aktif) dan status kamar diperbarui menjadi terisi.");
            } catch (Exception $e) {
                $conn->rollback();
                $pesan = alert_admin($e->getMessage());
            }
        }
    } elseif ($aksi == 'tolak') {
        $stmt = $conn->prepare("UPDATE users SET status_akun = 'ditolak' WHERE id = ? AND role != 'admin'");
        $stmt->bind_param('i', $id_user);
        $stmt->execute();
        $stmt->close();
        $pesan = alert_admin("Penyewa ditolak.");
    }
}

// 2. PROSES PERBAIKAN DATA PENYEWA + PENETAPAN KAMAR (FR-08)
if (isset($_POST['simpan_penyewa'])) {
    $id_user   = (int)$_POST['id_user'];
    $nama      = trim($_POST['nama']);
    $no_hp     = trim($_POST['no_hp']);
    $id_kamar  = ($_POST['id_kamar'] === '') ? null : (int)$_POST['id_kamar'];
    $validasi  = [];

    if (strlen($nama) < 3 || strlen($nama) > 100) $validasi[] = "Nama harus 3-100 karakter.";
    if (!preg_match('/^[0-9]{9,15}$/', $no_hp))   $validasi[] = "Nomor HP harus 9-15 digit angka.";

    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ? AND role != 'admin'");
    $stmt->bind_param('i', $id_user);
    $stmt->execute();
    $d_user = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$d_user) $validasi[] = "Akun penyewa tidak ditemukan.";

    if ($id_kamar !== null && empty($validasi)) {
        $stmt = $conn->prepare("SELECT * FROM kamar WHERE id = ?");
        $stmt->bind_param('i', $id_kamar);
        $stmt->execute();
        $kamar_baru = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$kamar_baru) {
            $validasi[] = "Kamar yang dipilih tidak tersedia.";
        } elseif ($kamar_baru['status'] !== 'tersedia' && $d_user['id_kamar'] != $id_kamar) {
            $validasi[] = "Kamar No. " . $kamar_baru['nomor_kamar'] . " berstatus " . $kamar_baru['status'] . ".";
        } else {
            $penghuni_lain = kamar_terpakai_lain($conn, $id_kamar, $id_user);
            if ($penghuni_lain) $validasi[] = "Kamar No. " . $kamar_baru['nomor_kamar'] . " sudah ditempati " . $penghuni_lain['nama'] . ".";
        }
    }

    if (!empty($validasi)) {
        $pesan = alert_admin(implode(" ", $validasi));
    } else {
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("UPDATE users SET nama = ?, no_hp = ?, id_kamar = ? WHERE id = ?");
            $stmt->bind_param('sssi', $nama, $no_hp, $id_kamar, $id_user);
            $stmt->execute();
            $stmt->close();

            // Kamar lama dikosongkan bila berpindah
            if (!empty($d_user['id_kamar']) && $d_user['id_kamar'] != $id_kamar) {
                $kamar_lama = (int)$d_user['id_kamar'];
                if (!kamar_terpakai_lain($conn, $kamar_lama, $id_user)) {
                    $stmt = $conn->prepare("UPDATE kamar SET status = 'tersedia' WHERE id = ?");
                    $stmt->bind_param('i', $kamar_lama);
                    $stmt->execute();
                    $stmt->close();
                }
            }

            if ($id_kamar !== null) {
                lepas_penghuni_lama($conn, $id_kamar, $id_user);
                $stmt = $conn->prepare("UPDATE kamar SET status = 'terisi' WHERE id = ?");
                $stmt->bind_param('i', $id_kamar);
                $stmt->execute();
                $stmt->close();
            }

            $conn->commit();
            $pesan = alert_admin("Data penyewa dan penempatan kamar berhasil disimpan.");
        } catch (Exception $e) {
            $conn->rollback();
            $pesan = alert_admin("Gagal menyimpan data: " . $e->getMessage());
        }
    }
}

// 3. PROSES HAPUS AKUN PENYEWA
if (isset($_GET['hapus']) && ctype_digit((string)$_GET['hapus'])) {
    $id_user = (int)$_GET['hapus'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ? AND role != 'admin'");
    $stmt->bind_param('i', $id_user);
    $stmt->execute();
    $d_user = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($d_user) {
        $conn->begin_transaction();
        try {
            if (!empty($d_user['id_kamar'])) {
                $id_kamar = (int)$d_user['id_kamar'];
                if (!kamar_terpakai_lain($conn, $id_kamar, $id_user)) {
                    $stmt = $conn->prepare("UPDATE kamar SET status = 'tersedia' WHERE id = ?");
                    $stmt->bind_param('i', $id_kamar);
                    $stmt->execute();
                    $stmt->close();
                }
            }
            $stmt = $conn->prepare("DELETE FROM tagihan WHERE user_id = ?");
            $stmt->bind_param('i', $id_user);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM komplain WHERE user_id = ?");
            $stmt->bind_param('i', $id_user);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->bind_param('i', $id_user);
            $stmt->execute();
            $stmt->close();

            if (!empty($d_user['ktp']) && is_file('../uploads/ktp/' . $d_user['ktp'])) {
                unlink('../uploads/ktp/' . $d_user['ktp']);
            }
            $conn->commit();
            $pesan = alert_admin("Akun penyewa dan data terkait berhasil dihapus.");
        } catch (Exception $e) {
            $conn->rollback();
            $pesan = alert_admin("Gagal menghapus: " . $e->getMessage());
        }
    }
}

// Daftar kamar untuk dropdown penetapan kamar (dimuat sekali, bukan per baris)
$kamar_semua = [];
$result_kamar = mysqli_query($conn, "SELECT id, nomor_kamar, tipe_kamar, harga, status FROM kamar ORDER BY nomor_kamar ASC");
while ($k = mysqli_fetch_assoc($result_kamar)) {
    $kamar_semua[$k['id']] = $k;
}

// Peta penghuni aktif per kamar, agar dropdown tidak memicu query per opsi
$penghuni_per_kamar = [];
$result_penghuni = $conn->query("SELECT id, id_kamar, nama FROM users WHERE id_kamar IS NOT NULL AND status_akun != 'ditolak'");
while ($p = $result_penghuni->fetch_assoc()) {
    $penghuni_per_kamar[$p['id_kamar']] = $p;
}

// Ambil daftar user role 'user' atau selain admin
$query_penyewa = $conn->query(
    "SELECT * FROM users WHERE role != 'admin'
     ORDER BY FIELD(status_akun,'pending','aktif','ditolak'), id DESC"
);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifikasi & Data Penyewa - Kosmos Admin</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f0f0; color: #111111; margin: 0; padding: 0; }
        .sidebar { width: 250px; background: #111111; color: #ffffff; position: fixed; height: 100%; padding: 20px; box-sizing: border-box; }
        .sidebar h2 { font-size: 20px; letter-spacing: 1px; text-align: center; margin-bottom: 30px; border-bottom: 1px solid #444; padding-bottom: 15px; }
        .sidebar a { display: block; color: #ffffff; text-decoration: none; padding: 10px 15px; margin-bottom: 8px; border-radius: 4px; font-size: 14px; }
        .sidebar a:hover, .sidebar a.active { background: #333333; }
        .sidebar a.logout { background: #ffffff; color: #111111; font-weight: bold; text-align: center; margin-top: 40px; }
        .main-content { margin-left: 250px; padding: 40px; box-sizing: border-box; }
        .card-table { background: #ffffff; padding: 25px; border: 2px solid #111111; border-radius: 6px; box-shadow: 4px 4px 0px #111111; }
        h2 { margin-top: 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #111111; padding: 12px; text-align: left; font-size: 14px; vertical-align: middle; }
        th { background: #111111; color: #ffffff; }
        .btn-terima { background: #111111; color: #fff; padding: 6px 12px; text-decoration: none; border-radius: 3px; font-size: 12px; font-weight: bold; display: inline-block; margin-bottom: 4px; }
        .btn-terima:hover { background: #333; }
        .btn-tolak { background: #666; color: #fff; padding: 6px 12px; text-decoration: none; border-radius: 3px; font-size: 12px; font-weight: bold; display: inline-block; margin-bottom: 4px; }
        .btn-tolak:hover { background: #444; }
        .btn-hapus { background: #fff; color: #111; border: 1.5px solid #111; padding: 5px 11px; text-decoration: none; border-radius: 3px; font-size: 12px; font-weight: bold; display: inline-block; }
        .btn-hapus:hover { background: #111; color: #fff; }
        .badge { padding: 4px 8px; border-radius: 3px; font-size: 11px; font-weight: bold; text-transform: uppercase; }
        .alert { padding: 12px 15px; background: #111; color: #fff; margin-bottom: 15px; border-radius: 4px; font-size: 13px; }
        .form-penyewa { display: flex; flex-wrap: wrap; gap: 10px; align-items: flex-end; }
        .form-penyewa label { display: block; font-size: 11px; font-weight: bold; text-transform: uppercase; color: #666; margin-bottom: 4px; }
        .form-penyewa input, .form-penyewa select { padding: 8px; border: 1.5px solid #111; border-radius: 4px; font-size: 13px; box-sizing: border-box; }
        .form-penyewa input[name="nama"] { min-width: 170px; }
        .form-penyewa input[name="no_hp"] { min-width: 130px; }
        .form-penyewa button { background: #111; color: #fff; border: none; padding: 9px 16px; border-radius: 4px; font-weight: bold; font-size: 13px; cursor: pointer; }
        .form-penyewa button:hover { background: #333; }
        .baris-edit td { background: #f5f5f5; }
    </style>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

    <div class="sidebar">
        <h2>KOSMOS ADMIN</h2>
        <a href="dashboard.php">Dashboard Utama</a>
        <a href="kelola-kamar.php">Kelola Kamar</a>
        <a href="verifikasi-penyewa.php" class="active">Verifikasi Penyewa</a>
        <a href="konfirmasi-pembayaran.php">Konfirmasi Pembayaran</a>
        <a href="kelola-tagihan.php">Kelola Tagihan</a>
        <a href="kelola-inventaris.php">Kelola Inventaris</a>
        <a href="kelola-laporan.php">Kelola Laporan</a>
        <a href="../logout.php" class="logout">LOGOUT</a>
    </div>

    <div class="main-content">
        <h1>Verifikasi & Data Penyewa</h1>
        <p style="color: #666; margin-bottom: 25px;">Periksa foto KTP calon penyewa, setujui pendaftaran, tetapkan kamar, dan perbarui data penghuni.</p>

        <?= $pesan; ?>

        <div class="card-table">
            <h2>Daftar Penyewa</h2>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama & Kontak</th>
                        <th>Kamar</th>
                        <th>Foto KTP</th>
                        <th>Status Akun</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    if ($query_penyewa && $query_penyewa->num_rows > 0) {
                        while ($row = $query_penyewa->fetch_assoc()) { 
                            $kid = !empty($row['id_kamar']) ? $row['id_kamar'] : null;
                            $data_kamar = $kid && isset($kamar_semua[$kid]) ? $kamar_semua[$kid] : null;
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td>
                            <strong><?= htmlspecialchars($row['nama']); ?></strong><br>
                            <span style="font-size: 12px; color: #666;"><?= htmlspecialchars($row['email']); ?></span><br>
                            <span style="font-size: 12px; color: #666;"><?= htmlspecialchars($row['no_hp']); ?></span>
                        </td>
                        <td>
                            <?php if ($data_kamar) { ?>
                                <strong>Kamar No. <?= htmlspecialchars($data_kamar['nomor_kamar']); ?></strong><br>
                                <span style="font-size: 12px; color: #666;"><?= htmlspecialchars($data_kamar['tipe_kamar']); ?></span>
                            <?php } else { ?>
                                <span style="color: #666; font-size: 12px;">Belum ada kamar</span>
                            <?php } ?>
                        </td>
                        <td>
                            <?php if (!empty($row['ktp'])) { ?>
                                <a href="../uploads/ktp/<?= htmlspecialchars($row['ktp']); ?>" target="_blank">
                                    <img src="../uploads/ktp/<?= htmlspecialchars($row['ktp']); ?>" width="90" height="60" style="object-fit: cover; border-radius: 3px; border: 1px solid #111;" title="Klik untuk memperbesar">
                                </a>
                            <?php } else { ?>
                                <span style="font-size: 11px; color: #666;">Tidak ada KTP</span>
                            <?php } ?>
                        </td>
                        <td>
                            <?php if ($row['status_akun'] == 'aktif') { ?>
                                <span class="badge" style="background: #111; color: #fff;">Aktif</span>
                            <?php } elseif ($row['status_akun'] == 'ditolak') { ?>
                                <span class="badge" style="background: #ccc; color: #333;">Ditolak</span>
                            <?php } else { ?>
                                <span class="badge" style="background: #eee; color: #333; border: 1px solid #111;">Pending</span>
                            <?php } ?>
                        </td>
                        <td>
                            <?php if ($row['status_akun'] != 'aktif') { ?>
                                <a href="verifikasi-penyewa.php?aksi=terima&id=<?= (int)$row['id']; ?>" class="btn-terima" onclick="return confirm('Terima penyewa ini?')">Terima</a>
                                <a href="verifikasi-penyewa.php?aksi=tolak&id=<?= (int)$row['id']; ?>" class="btn-tolak" onclick="return confirm('Tolak penyewa ini?')">Tolak</a>
                            <?php } ?>
                            <a href="verifikasi-penyewa.php?hapus=<?= (int)$row['id']; ?>" class="btn-hapus" onclick="return confirm('Hapus akun penyewa beserta tagihan dan laporannya?')">Hapus</a>
                        </td>
                    </tr>
                    <tr class="baris-edit">
                        <td colspan="6">
                            <form action="" method="POST" class="form-penyewa">
                                <input type="hidden" name="id_user" value="<?= (int)$row['id']; ?>">
                                <div>
                                    <label>Nama Penyewa</label>
                                    <input type="text" name="nama" value="<?= htmlspecialchars($row['nama']); ?>" required>
                                </div>
                                <div>
                                    <label>No. HP</label>
                                    <input type="text" name="no_hp" value="<?= htmlspecialchars($row['no_hp']); ?>" pattern="[0-9]{9,15}" required>
                                </div>
                                <div>
                                    <label>Penetapan Kamar</label>
                                    <select name="id_kamar">
                                        <option value="">-- Tanpa kamar --</option>
                                        <?php foreach ($kamar_semua as $k) { 
                                            $sedang_dipakai = ($kid == $k['id']);
                                            if ($k['status'] !== 'tersedia' && !$sedang_dipakai) continue;
                                            $pemegang = isset($penghuni_per_kamar[$k['id']]) ? $penghuni_per_kamar[$k['id']] : null;
                                            $dipakai_penghuni_lain = $pemegang && $pemegang['id'] != $row['id'];
                                        ?>
                                            <option value="<?= (int)$k['id']; ?>" <?= $sedang_dipakai ? 'selected' : '' ?>>
                                                No. <?= htmlspecialchars($k['nomor_kamar']); ?> - <?= htmlspecialchars($k['tipe_kamar']); ?>
                                                <?= $sedang_dipakai ? '(saat ini)' : ($dipakai_penghuni_lain ? '(ditempati ' . htmlspecialchars($pemegang['nama']) . ')' : ''); ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div>
                                    <button type="submit" name="simpan_penyewa">SIMPAN DATA & KAMAR</button>
                                </div>
                            </form>
                        </td>
                    </tr>
                    <?php 
                        }
                    } else { 
                    ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: #666; padding: 20px;">Belum ada pendaftaran penyewa.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>
